import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpEventsModule } from '../events/events.module';
import { RpFormTextModule } from '../form/form-text/form-text.module';
import { RpPropertyPickerComponent } from './property-picker/property-picker.component';

@NgModule({
  declarations: [
    RpPropertyPickerComponent
  ],

  imports: [
    CommonModule,
    RpEventsModule,
    RpFormTextModule
  ],

  exports: [
    RpPropertyPickerComponent
  ],

  providers: [

  ]
})

export class RpPropertyPickerModule { }
