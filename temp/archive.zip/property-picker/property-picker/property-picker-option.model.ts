import { RpPropertyPickerOptionData as OptionData } from './property-picker-option-data.interface';

export class RpPropertyPickerOptionModel {
  relevant = true;
  selected = false;
  data: OptionData;

  constructor(data: OptionData) {
    const defaults = {
      name: '',
      city: '',
      state: '',
      siteId: '',
      address: '',
      country: '',
      locked: false,
      entityName: '',
      zip: ''
    };

    this.data = { ...defaults, ...data };
  }

  destroy(): void {
    this.data = undefined;
    this.selected = undefined;
    this.relevant = undefined;
  }

  getData(): OptionData {
    return this.data;
  }

  getName(): string {
    return this.data.name;
  }

  getState() {
    return {
      relevant: this.relevant,
      selected: this.selected,
      locked: this.data.locked
    };
  }

  hasSiteId(siteId): boolean {
    return this.data.siteId === siteId;
  }

  is(item: RpPropertyPickerOptionModel): boolean {
    return item === this;
  }

  isLocked(): boolean {
    return this.data.locked;
  }

  isRelevant(): boolean {
    return this.relevant;
  }

  isSelected(): boolean {
    return this.selected;
  }

  setSelected(bool: boolean = true) {
    this.selected = bool;
  }

  updateRelevance(text: string) {
    const name = this.data.name.toLowerCase(),
      address = this.data.address.toLowerCase();

    this.relevant = true;

    if (text) {
      text = text.toLowerCase();
      this.relevant = !!(name.match(text) || address.match(text));
    }
  }
}
