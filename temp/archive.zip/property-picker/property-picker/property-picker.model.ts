import { PubSub } from '../../common/services/pubsub.service';
import { RpPropertyPickerOptionModel as Option } from './property-picker-option.model';

export class RpPropertyPickerModel {
  limit = 6;
  pubsub: PubSub;
  allProps: Option;

  searchText = '';
  searchConfig: any;

  options: Option[];
  _options: Option[];

  constructor() {
    this.options = [];
    this._options = [];

    this.pubsub = new PubSub();

    this.allProps = new Option({
      name: 'All Properties'
    });

    this.allProps.setSelected();
  }

  destroy(): void {
    this.destroyOptions();
  }

  destroyOptions(): void {
    this._options.forEach((option) => {
      option.destroy();
    });

    this.options = [];
    this._options = [];
  }

  getOptionsCount(): number {
    return this._options.length;
  }

  hasRelevantOptions(): boolean {
    return this.options.length !== 0;
  }

  increaseLimit(): void {
    if (this.limit === this.options.length) {
      return;
    }

    this.limit += 2;

    if (this.limit > this.options.length) {
      this.limit = this.options.length;
    }
  }

  onSearch(text: string) {
    this.limit = 6;

    this.options = this._options.filter((option) => {
      option.updateRelevance(text);
      return option.isRelevant();
    });
  }

  selectOption(option: Option): void {
    if (option.isLocked() || option.isSelected()) {
      return;
    }

    this.allProps.setSelected(option.is(this.allProps));

    this.options.forEach((item) => {
      item.setSelected(item.is(option));
    });

    this.pubsub.publish('propertyPicker.selectProperty', option.getData());
    this.pubsub.publish('propertyPicker.updatePropertyName', option.getData());
  }

  setOptions(list: any[]) {
    this.destroyOptions();

    this._options = list.map((data) => {
      return new Option(data);
    });

    this.options = this._options;
  }

  updateSelection(siteId: number): void {
    let name = 'All Properties';

    this._options.forEach((option) => {
      const selected = option.hasSiteId(siteId);
      option.setSelected(selected);

      if (selected) {
        name = option.getName();
      }
    });

    this.allProps.setSelected(name === 'All Properties');

    this.pubsub.publish('propertyPicker.updatePropertyName', {
      name: name
    });
  }
}
