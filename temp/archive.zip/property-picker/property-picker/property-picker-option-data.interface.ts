export interface RpPropertyPickerOptionData {
  name?: string;
  city?: string;
  state?: string;
  siteId?: string;
  address?: string;
  country?: string;
  locked?: boolean;
  entityName?: string;
  zip?: string;
}
