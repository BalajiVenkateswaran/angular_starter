import { Component, ViewEncapsulation, Inject, OnDestroy, OnInit } from '@angular/core';
import { RpPropertyPickerModel as Model } from './property-picker.model';
import { RpPropertyPickerOptionModel as Option } from './property-picker-option.model';
import { PubSub } from '../../common/services/pubsub.service';
import { RpFormTextConfigData as SearchConfig } from '../../form/form-text/form-text-config-data.interface';

@Component({
  selector: 'rp-property-picker',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './property-picker.component.html',
  styleUrls: ['./property-picker.component.scss']
})

export class RpPropertyPickerComponent implements OnInit, OnDestroy {
  model: Model;
  menuVisible = false;
  toggleWatch: Function;
  selectionWatch: Function;

  searchText = '';
  searchConfig: SearchConfig;

  menuStyle: {
    top: number;
    left: number;
  };

  options: any[];

  constructor(@Inject('Window') private win, private pubsub: PubSub) {
    this.model = new Model();

    const toggleEvt = 'propertyPicker.toggleMenu',
      updEvt = 'propertyPicker.updateSelection',
      toggleMenu = this.toggleMenu.bind(this),
      updateSelection = this.updateSelection.bind(this);

    this.menuStyle = {
      top: undefined,
      left: undefined
    };

    this.searchConfig = {
      placeholder: 'search',
      iconClass: 'fa fa-search',
      onChange: this.onSearch.bind(this),
      modelOptions: {
        updateOn: 'change'
      }
    };

    this.toggleWatch = this.pubsub.subscribe(toggleEvt, toggleMenu);
    this.selectionWatch = this.pubsub.subscribe(updEvt, updateSelection);
  }

  getMenuState() {
    return {
      active: this.menuVisible
    };
  }

  getMenuStyle() {
    if (this.menuStyle.top === undefined) {
      return {};
    }

    return {
      'top.px': this.menuStyle.top,
      'left.px': this.win.innerWidth < 544 ? 0 : this.menuStyle.left
    };
  }

  ngOnInit() {
    this.pubsub.publish('propertyPicker.init');
  }

  ngOnDestroy() {
    this.toggleWatch();
    this.selectionWatch();
    this.model.destroy();

    this.model = undefined;
    this.toggleWatch = undefined;
    this.selectionWatch = undefined;
  }

  onSearch(text) {
    this.model.onSearch(text);
  }

  selectOption(option: Option) {
    this.model.selectOption(option);
  }

  toggleMenu(data: { visible: boolean; top: number; left: number; }) {
    this.menuVisible = data.visible;

    this.menuStyle = {
      top: data.top,
      left: data.left
    };
  }

  updateSelection(siteId: number) {
    this.model.updateSelection(siteId);
  }
}
