import { NgModule } from '@angular/core';

import { RpAccordionModule } from './accordion/accordion.module';
import { RpAppRootModule } from './root/app-root.module';
import { RpBreadcrumbsModule } from './breadcrumbs/breadcrumbs.module';
import { RpCollapseModule } from './collapse/collapse.module';
import { RpCommonModule } from './common/common.module';
import { RpCopyContentModule } from './copy-content/copy-content.module';
import { RpDatepickerModule } from './datepicker/datepicker.module';
import { RpEventsModule } from './events/events.module';
import { RpFormModule } from './form/form.module';
import { RpHeaderModule } from './header/header.module';
import { RpIconModule } from './icon/icon.module';
import { RpModalModule } from './modal/modal.module';
import { RpNavModule } from './nav/nav.module';
import { RpPageTitleModule } from './page-title/page-title.module';
import { RpPropertyPickerModule } from './property-picker/property-picker.module';
import { RpSampleCodeModule } from './sample-code/sample-code.module';
import { RpSvgIconModule } from './svg-icon/svg-icon.module';
import { RpTabsModule } from './tabs/tabs.module';
import { RpToggleModule } from './toggle/toggle.module';

@NgModule({
  exports: [
    RpAccordionModule,
    RpAppRootModule,
    RpBreadcrumbsModule,
    RpCollapseModule,
    RpCommonModule,
    RpCopyContentModule,
    RpDatepickerModule,
    RpEventsModule,
    RpFormModule,
    RpHeaderModule,
    RpIconModule,
    RpModalModule,
    RpNavModule,
    RpPageTitleModule,
    RpPropertyPickerModule,
    RpSampleCodeModule,
    RpSvgIconModule,
    RpTabsModule,
    RpToggleModule
  ]
})

export class RpAngularComponentsModule { }
