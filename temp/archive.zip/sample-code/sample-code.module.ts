import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpSampleCodeComponent } from './sample-code/sample-code.component';
import { RpCommonModule } from '../common/common.module';

@NgModule({
  declarations: [
    RpSampleCodeComponent
  ],

  imports: [
    CommonModule,
    RpCommonModule
  ],

  exports: [
    RpSampleCodeComponent
  ]
})

export class RpSampleCodeModule { }
