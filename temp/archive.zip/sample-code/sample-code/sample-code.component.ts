import {
  Component,
  ElementRef,
  Input,
  ViewChild,
  ViewEncapsulation,
  OnInit
} from '@angular/core';
import { RpCopyContentService as CopySvc } from '../../copy-content/copy-content/copy-content.service';

@Component({
  preserveWhitespaces: true,
  selector: 'rp-sample-code',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './sample-code.component.html',
  styleUrls: ['./sample-code.component.scss']
})

export class RpSampleCodeComponent implements OnInit {
  collapsed = true;
  hideExpand = true;

  @Input() trimSpace: number;

  @ViewChild('content') content: ElementRef;

  constructor(
    private elem: ElementRef,
    private copySvc: CopySvc) { }

  copyContent(): void {
    const text = this.content.nativeElement.children[0].innerText;
    this.copySvc.copyContent(text);
  }

  expand() {
    this.collapsed = !this.collapsed;
  }

  getState() {
    return {
      collapsed: this.collapsed
    };
  }

  ngOnInit() {
    this.hideExpand = this.elem.nativeElement.offsetHeight < 250;
  }
}
