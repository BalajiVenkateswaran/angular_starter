import { NgModule } from '@angular/core';
import { RpModalService } from './modal/modal.service';
import { RpModalComponent } from './modal/modal.component';

@NgModule({
  declarations: [
    RpModalComponent
  ],

  imports: [

  ],

  exports: [
    RpModalComponent
  ],

  providers: [
    RpModalService
  ],

  entryComponents: [
    RpModalComponent
  ]
})

export class RpModalModule { }
