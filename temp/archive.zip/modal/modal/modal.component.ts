import {
  Component,
  ComponentFactoryResolver,
  ComponentRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewContainerRef,
  ViewEncapsulation,
  ElementRef,
  Renderer2
} from '@angular/core';

import { RpDomService as DomSvc } from '../../common/services/dom.service';
import { RpComponentConfig as CompConfig } from '../../common/interfaces/component-config.interface';

@Component({
  selector: 'rp-modal',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})

export class RpModalComponent implements OnInit, OnDestroy {
  unbindClick: Function;
  compRef: ComponentRef<any>;

  @Input() comp: any;
  @Input() compConfig: CompConfig;

  @ViewChild('overlay', { read: ViewContainerRef }) overlay: ViewContainerRef;

  constructor(
    private domSvc: DomSvc,
    private elem: ElementRef,
    private renderer: Renderer2,
    private resolver: ComponentFactoryResolver) { }

  addModalTheme(): void {
    this.elem.nativeElement.classList.add(this.getModalTheme());
  }

  addOverlayClass(className: string): void {
    this.overlay.element.nativeElement.classList.add(className);
  }

  attachModalContent(): void {
    const factory = this.resolver.resolveComponentFactory(this.comp);
    this.compRef = this.overlay.createComponent(factory);
    this.domSvc.attachConfig(this.compRef, this.compConfig);
    this.compRef.location.nativeElement.classList.add('rp-modal');
    this.compRef.changeDetectorRef.detectChanges();
  }

  bindClick(): Function {
    const onClick = this.onElemClick.bind(this);
    return this.renderer.listen(this.elem.nativeElement, 'click', onClick);
  }

  detachModalContent(): void {
    this.domSvc.detachView(this.compRef.hostView);
    this.compRef.destroy();
  }

  dispatchHideEvent(): void {
    const hideModal = new CustomEvent('hideModal', { bubbles: true });

    setTimeout(() => {
      this.elem.nativeElement.dispatchEvent(hideModal);
    }, 300);
  }

  getModalTheme(): string {
    return this.compConfig.inputs['theme'] || 'theme-1';
  }

  ngOnDestroy(): void {
    this.unbindClick();
    this.detachModalContent();
  }

  ngOnInit() {
    this.attachModalContent();
    this.addModalTheme();

    this.unbindClick = this.bindClick();

    setTimeout(() => {
      this.addOverlayClass('active');
    });
  }

  onElemClick(event): void {
    if (event.target.classList.contains('hide-modal')) {
      this.removeOverlayClass('active');
      this.dispatchHideEvent();
    }
  }

  removeOverlayClass(className: string): void {
    this.overlay.element.nativeElement.classList.remove(className);
  }
}
