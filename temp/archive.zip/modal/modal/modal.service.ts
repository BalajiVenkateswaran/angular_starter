import {
  ComponentRef,
  Injectable,
  RendererFactory2,
  Renderer2,
  ElementRef
} from '@angular/core';

import { RpModalComponent as ModalComponent } from './modal.component';
import { RpDomService as DomSvc } from '../../common/services/dom.service';
import { RpComponentConfig as CompConfig } from '../../common/interfaces/component-config.interface';

@Injectable()

export class RpModalService {
  renderer: Renderer2;
  hideModal: Function;
  unbindHide: Function;

  constructor(
    private domSvc: DomSvc,
    private rendererFactory: RendererFactory2) {
    this.renderer = this.rendererFactory.createRenderer(null, null);
  }

  showModal(comp: any, compConfig?: CompConfig): Function {
    const modal = this.genModal(comp, compConfig),
      modalElem = this.domSvc.genCompElem(modal);

    this.unbindHide = this.bindHide(modalElem);
    document.body.classList.add('rp-modal-active');
    this.domSvc.appendElem('rp-app-root', modalElem);

    this.hideModal = () => {
      this.unbindHide();
      this.domSvc.detachView(modal.hostView);
      document.body.classList.remove('rp-modal-active');
      modal.destroy();
    };

    return this.hideModal;
  }

  bindHide(elem: HTMLElement): Function {
    return this.renderer.listen(elem, 'hideModal', () => {
      this.hideModal();
    });
  }

  genModal(comp: any, compConfig: CompConfig): ComponentRef<any> {
    const modal = this.domSvc.genCompRef(ModalComponent);

    this.domSvc.attachConfig(modal, {
      inputs: {
        comp: comp,
        compConfig: compConfig
      }
    });

    this.domSvc.attachView(modal.hostView);
    return modal;
  }
}
