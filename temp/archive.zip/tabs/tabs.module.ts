import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpTabsComponent } from './tabs/tabs.component';

@NgModule({
  declarations: [
    RpTabsComponent
  ],

  imports: [
    CommonModule
  ],

  exports: [
    RpTabsComponent
  ]
})

export class RpTabsModule { }
