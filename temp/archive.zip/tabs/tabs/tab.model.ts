import { RpTabData as TabData } from './tab-data.interface';

export class RpTabModel {
  data: TabData;

  constructor(data: TabData) {
    this.data = data;
  }

  getId() {
    return this.data.id;
  }

  getState() {
    return {
      active: this.data.active,
      disabled: this.data.disabled
    };
  }

  hasId(id): boolean {
    return this.data.id === id;
  }

  hasUrl() {
    return this.data.url !== undefined;
  }

  isActive(): boolean {
    return this.data.active;
  }

  isDisabled(): boolean {
    return this.data.disabled || false;
  }

  setActive(bool: boolean): void {
    this.data.active = bool;
  }

  destroy() {
    this.data = undefined;
  }
}
