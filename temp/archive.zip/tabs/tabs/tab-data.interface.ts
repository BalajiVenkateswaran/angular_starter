export interface RpTabData {
  id: string;
  url?: string;
  text: string;
  active: boolean;
  disabled?: boolean;
  classNames?: string;
}
