import { RpTabModel as TabModel } from './tab.model';
import { RpTabData as TabData } from './tab-data.interface';

export class RpTabsModel {
  list: {};
  tabs: TabModel [] = [];

  constructor(list: TabData[] = []) {
    this.list = {};
    this.setData(list);
  }

  activateTab(tab: TabModel): void {
    if (tab.isDisabled()) {
      return;
    }

    this.tabs.forEach((item) => {
      const active = item === tab;
      item.setActive(active);

      if (active && tab.hasUrl()) {

      }
    });
  }

  activateTabId(tabId: string): void {
    this.tabs.forEach((tab: TabModel) => {
      if (!tab.isDisabled()) {
        tab.setActive(tab.hasId(tabId));
      }
    });
  }

  isActive(id: string): boolean {
    return this.list[id].isActive();
  }

  setData(list: TabData [] = []): void {
    list.forEach((item) => {
      const tab = new TabModel(item);
      this.tabs.push(tab);
      this.list[tab.getId()] = tab;
    });
  }

  destroy(): void {
    this.tabs.forEach((tab) => {
      tab.destroy();
    });

    this.list = undefined;
    this.tabs = undefined;
  }
}
