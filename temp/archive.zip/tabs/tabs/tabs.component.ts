import { Component, Input, ViewEncapsulation } from '@angular/core';
import { RpTabModel as TabModel } from './tab.model';
import { RpTabData as TabData } from './tab-data.interface';
import { RpTabsModel as TabsModel } from './tabs.model';

@Component({
  selector: 'rp-tabs',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})

export class RpTabsComponent {
  tabsModel: TabsModel;

  @Input('data') public set setData(data: TabData[]) {
    this.tabsModel.setData(data);
  }

  constructor() {
    this.tabsModel = new TabsModel();
  }

  activateTab(tab: TabModel): void {
    this.tabsModel.activateTab(tab);
  }
}
