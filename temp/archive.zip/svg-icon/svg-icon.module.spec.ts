import { RpSvgIconModule } from './svg-icon.module';

describe('SvgIconModule', () => {
  let svgIconModule: RpSvgIconModule;

  beforeEach(() => {
    svgIconModule = new RpSvgIconModule();
  });

  it('should create an instance', () => {
    expect(svgIconModule).toBeTruthy();
  });
});
