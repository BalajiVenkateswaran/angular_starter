import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpSvgIconPath } from './svg-icon/svg-icon.pipe';
import { RpSvgIconConfigProvider } from './svg-icon/svg-icon-config.provider';

@NgModule({
  declarations: [
    RpSvgIconPath
  ],

  imports: [
    CommonModule
  ],

  exports: [
    RpSvgIconPath
  ],

  providers: [
    RpSvgIconConfigProvider
  ]
})

export class RpSvgIconModule { }
