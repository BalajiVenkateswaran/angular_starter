export interface RpSvgIconConfigInterface {
  path: string;
}
