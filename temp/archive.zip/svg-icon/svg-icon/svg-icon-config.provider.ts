import { RpSvgIconConfigInterface } from './svg-icon-config.interface';

const config: RpSvgIconConfigInterface = {
  path: ''
};

export let RpSvgIconConfigProvider = {
  useValue: config,
  provide: 'RpSvgIconConfig'
};
