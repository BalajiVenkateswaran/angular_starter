import { Pipe, PipeTransform, Inject } from '@angular/core';
import { RpSvgIconConfigInterface } from './svg-icon-config.interface';

@Pipe({
  name: 'rpSvgIconPath'
})

export class RpSvgIconPath implements PipeTransform {
  config: RpSvgIconConfigInterface;

  constructor(@Inject('RpSvgIconConfig') config) {
    this.config = config;
  }

  transform(iconName: string): string {
    return `${this.config.path}${iconName}.svg`;
  }
}
