import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpToggleComponent } from './toggle/toggle.component';

@NgModule({
  declarations: [
    RpToggleComponent
  ],

  imports: [
    CommonModule
  ],

  exports: [
    RpToggleComponent
  ]
})

export class RpToggleModule { }
