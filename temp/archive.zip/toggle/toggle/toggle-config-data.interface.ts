export interface RpToggleConfigData {
  activeClass: string;
  activeIconClass: string;
  activeText: string;
  bodyToggle: boolean;
  defaultClass: string;
  defaultIconClass: string;
  defaultText: string;
}
