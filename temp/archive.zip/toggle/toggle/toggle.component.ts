import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation,
  Renderer2,
  OnDestroy
} from '@angular/core';
import { RpToggleConfigData as ConfigData } from './toggle-config-data.interface';

@Component({
  selector: 'rp-toggle',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './toggle.component.html',
  styleUrls: ['./toggle.component.scss']
})

export class RpToggleComponent implements OnInit, OnDestroy {
  defVal: boolean;
  unbind: Function;

  @Input() model: boolean;
  @Input() disabled: boolean;
  @Output() modelChange = new EventEmitter<boolean>();

  @Input('config') public set setConfig(data: ConfigData) {
    this.config = { ...this.defaultConfig, ...data };
  }

  config: ConfigData;
  defaultConfig: ConfigData;

  constructor(private renderer: Renderer2) {
    this.defaultConfig = {
      activeClass: '',
      activeIconClass: '',
      activeText: '',
      bodyToggle: true,
      defaultClass: '',
      defaultIconClass: '',
      defaultText: ''
    };

    this.unbind = () => { };
  }

  getState() {
    const state = {};
    if (this.model) {
      state[this.config.activeClass] = true;
    } else {
      state[this.config.defaultClass] = true;
    }
    state['disabled'] = this.disabled;
    return state;
  }

  getIconState() {
    const state = {};
    if (this.model) {
      state[this.config.activeIconClass] = true;
    } else {
      state[this.config.defaultIconClass] = true;
    }
    state['disabled'] = this.disabled;
    return state;
  }

  ngOnDestroy() {
    this.unbind();
    this.config = undefined;
    this.defVal = undefined;
    this.defaultConfig = undefined;
  }

  ngOnInit() {
    this.model = !!this.model;
    this.defVal = this.model;
    this.config = { ...this.defaultConfig, ...this.config };
  }

  reset() {
    if (this.config.bodyToggle && this.disabled !== true) {
      this.unbind();
      this.model = this.defVal;
      this.modelChange.emit(this.model);
    }
  }

  toggle() {
    if (this.disabled !== true) {
      this.unbind();
      this.model = !this.model;
      this.modelChange.emit(this.model);

      if (this.model !== this.defVal) {
        setTimeout(() => {
          this.unbind = this.renderer.listen('document', 'click', this.reset.bind(this));
        }, 200);
      }
    }
  }
}
