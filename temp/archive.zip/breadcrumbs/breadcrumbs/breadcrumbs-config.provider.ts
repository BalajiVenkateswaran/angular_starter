import { RpBreadcrumbsConfigData } from './breadcrumbs-config-data.interface';

export const config: RpBreadcrumbsConfigData = [
  {
    url: /.*/,

    links: [
      {
        href: '/',
        text: 'Starter'
      }
    ],

    activePage: {
      text: 'Home'
    },

    appHeader: {
      text: 'Home'
    }
  }
];

export let RpBreadcrumbsConfigProvider = {
  useValue: config,
  provide: 'RpBreadcrumbsConfig'
};
