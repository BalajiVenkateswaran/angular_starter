export interface RpBreadcrumbsConfigData {
  [index: number]: {
    url: RegExp,

    links: {
      href: string;
      text: string;
    }[],

    activePage: {
      text: string
    },

    appHeader: {
      text: string
    }
  };
}
