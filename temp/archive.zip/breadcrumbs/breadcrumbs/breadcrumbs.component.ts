import { Router, NavigationStart } from '@angular/router';
import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'rp-breadcrumbs',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss']
})

export class RpBreadcrumbsComponent implements OnInit {
  data = {
    links: [
      {
        href: '',
        text: ''
      }
    ],

    activePage: {
      text: ''
    },

    appHeader: {
      text: ''
    }
  };

  backLink = {
    text: ''
  };

  collapsePanel = true;

  constructor(
    private router: Router,
    @Inject('RpBreadcrumbsConfig') private config) {
    this.router.events.subscribe(this.onNavStart.bind(this));
  }

  getState(): any {
    return {};
  }

  goBack(): void {

  }

  ngOnInit() {

  }

  onNavStart(e): void {
    if (e instanceof NavigationStart) {
      this.updateData(e);
    }
  }

  onWinResize() {

  }

  toggleMenu() {

  }

  updateData(e: NavigationStart): void {
    let found = false;

    this.config.forEach((item) => {
      if (!found && e.url.match(item.url)) {
        found = true;
        this.data = item;
      }
    });
  }
}
