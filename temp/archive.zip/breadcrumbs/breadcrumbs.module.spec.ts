import { RpBreadcrumbsModule } from './breadcrumbs.module';

describe('BreadcrumbsModule', () => {
  let breadcrumbsModule: RpBreadcrumbsModule;

  beforeEach(() => {
    breadcrumbsModule = new RpBreadcrumbsModule();
  });

  it('should create an instance', () => {
    expect(breadcrumbsModule).toBeTruthy();
  });
});
