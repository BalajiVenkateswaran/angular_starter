import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { RpToggleModule } from '../toggle/toggle.module';
import { RpCollapseModule } from '../collapse/collapse.module';
import { RpBreadcrumbsComponent } from './breadcrumbs/breadcrumbs.component';
import { RpBreadcrumbsConfigProvider } from './breadcrumbs/breadcrumbs-config.provider';

@NgModule({
  declarations: [
    RpBreadcrumbsComponent
  ],

  imports: [
    CommonModule,
    RouterModule,
    RpToggleModule,
    RpCollapseModule
  ],

  exports: [
    RpBreadcrumbsComponent
  ],

  providers: [
    RpBreadcrumbsConfigProvider
  ]
})
export class RpBreadcrumbsModule { }
