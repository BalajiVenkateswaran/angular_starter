import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { RpFormSelectComponent } from './form-select.component';
import { RpFormSelectValidatorDirective } from './form-select-validator.directive';

@NgModule({
  declarations: [
    RpFormSelectComponent,
    RpFormSelectValidatorDirective
  ],

  imports: [
    FormsModule,
    CommonModule
  ],

  exports: [
    RpFormSelectComponent,
    RpFormSelectValidatorDirective
  ]
})

export class RpFormSelectModule { }
