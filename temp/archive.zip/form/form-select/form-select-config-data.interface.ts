import { RpValidationMsg } from '../../common/interfaces/validation-msg.interface';
import { RpValidator } from '../../common/interfaces/validator.interface';

type RpFormSelectOptionsFilter = (options: any []) => any [];

export interface RpFormSelectConfigData {
  asyncValidators?: RpValidator[];
  disabled?: boolean;
  errorMsgs?: RpValidationMsg[];
  fieldId?: string;
  fieldName?: string;
  groupKey?: string;
  nameKey?: string;
  onChange?: Function;
  options?: {} [];
  optionsFilter?: {} | RpFormSelectOptionsFilter;
  readonly?: boolean;
  required?: boolean;
  validators?: RpValidator[];
  valueKey?: string;
}
