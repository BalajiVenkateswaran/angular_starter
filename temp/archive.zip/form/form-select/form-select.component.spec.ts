import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpFormSelectComponent } from './form-select.component';

describe('FormSelectComponent', () => {
  let component: RpFormSelectComponent;
  let fixture: ComponentFixture<RpFormSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpFormSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpFormSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
