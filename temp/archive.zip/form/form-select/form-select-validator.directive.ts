import { Directive, Input, OnInit } from '@angular/core';
import { NG_VALIDATORS } from '@angular/forms';
import { RpFormSelectConfigModel as ConfigModel } from './form-select-config.model';
import { RpFormBaseValidator as BaseValidator } from '../form-common/form-base-validator.class';

@Directive({
  selector: '[rpFormSelectValidator]',
  providers: [
    {
      multi: true,
      provide: NG_VALIDATORS,
      useExisting: RpFormSelectValidatorDirective
    }
  ]
})

export class RpFormSelectValidatorDirective extends BaseValidator implements OnInit {
  @Input('rpFormSelectValidator') config: ConfigModel;

  ngOnInit() {
    this.validators = this.config.getValidators();
  }
}
