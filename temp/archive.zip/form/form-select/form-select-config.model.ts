import { RpFormSelectConfigData as ConfigData } from './form-select-config-data.interface';
import { RpFormBaseConfigModel as BaseConfigModel } from '../form-common/form-base-config.model';

export class RpFormSelectConfigModel extends BaseConfigModel {
  static index = 1;

  options: any[];
  data: ConfigData;
  defaults: ConfigData;

  constructor(data: ConfigData = {}) {
    super();

    const noop = () => { },
      name = `form-select-${RpFormSelectConfigModel.index++}`;

    this.defaults = {
      asyncValidators: [],
      disabled: false,
      errorMsgs: [],
      fieldId: name,
      fieldName: name,
      groupKey: '',
      nameKey: 'name',
      onChange: noop,
      options: [],
      optionsFilter: {},
      readonly: false,
      required: false,
      validators: [],
      valueKey: 'value'
    };

    this.updateData(data);
  }

  destroy(): void {
    this.data = undefined;
    this.defaults = undefined;
  }

  filterOptions(filter: any) {
    if (filter.bind) {
      this.options = filter(this.data.options);
    } else {
      let filtered = [];
      const options = [];

      this.data.options.forEach((item) => {
        if (item[this.data.valueKey] === '') {
          options.push(item);
        } else {
          filtered.push(item);
        }
      });

      if (filter[this.data.nameKey]) {
        filtered = filtered.filter((item) => {
          return !!item[this.data.nameKey].match(filter[this.data.nameKey]);
        });
      } else if (filter[this.data.valueKey]) {
        filtered = filtered.filter((item) => {
          return !!item[this.data.valueKey].match(filter[this.data.valueKey]);
        });
      }

      this.options = options.concat(filtered);
    }
  }

  getOptionName(optVal: string): string {
    let name = '';

    this.data.options.forEach((option) => {
      if (option[this.data.valueKey] === optVal) {
        name = option[this.data.nameKey];
      }
    });

    return name;
  }

  onChange(data: any): void {
    this.data.onChange(data);
  }

  updateData(data: ConfigData): void {
    super.updateData(data);
    this.options = this.data.options;
  }
}
