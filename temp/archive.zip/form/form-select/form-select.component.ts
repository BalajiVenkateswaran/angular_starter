import {
  Component,
  OnInit,
  Input,
  ViewEncapsulation,
  OnDestroy
} from '@angular/core';
import { RpFormSelectConfigModel as ConfigModel } from './form-select-config.model';
import { RpFormBaseComponent as BaseComponent } from '../form-common/form-base.component';
import { RpFormSelectConfigData as ConfigData } from './form-select-config-data.interface';

@Component({
  selector: 'rp-form-select',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './form-select.component.html',
  styleUrls: ['./form-select.component.scss']
})

export class RpFormSelectComponent extends BaseComponent implements OnInit, OnDestroy {
  config: ConfigModel;

  @Input('config') public set setConfig(data: ConfigData) {
    this.config.updateData(data);
  }

  constructor() {
    super();
    this.config = new ConfigModel();
  }

  getDisplayText(): string {
    return this.config.getOptionName(this.model);
  }

  ngOnInit(): void {
    this.state['has-error-msgs'] = this.config.hasErrorMsgs();
  }

  ngOnDestroy(): void {
    this.config.destroy();
    this.config = undefined;
  }

  onChange(): void {
    setTimeout(() => {
      super.emitChange();
      this.config.onChange(this.model);
    });
  }
}
