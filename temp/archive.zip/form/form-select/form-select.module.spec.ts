import { RpFormSelectModule } from './form-select.module';

describe('FormSelectModule', () => {
  let formSelectModule: RpFormSelectModule;

  beforeEach(() => {
    formSelectModule = new RpFormSelectModule();
  });

  it('should create an instance', () => {
    expect(formSelectModule).toBeTruthy();
  });
});
