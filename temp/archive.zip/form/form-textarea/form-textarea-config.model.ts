import { RpFormTextareaConfigData as ConfigData } from './form-textarea-config-data.interface';
import { RpFormBaseConfigModel as BaseConfigModel } from '../form-common/form-base-config.model';

export class RpFormTextareaConfigModel extends BaseConfigModel {
  static index = 1;

  data: ConfigData;
  defaults: ConfigData;

  constructor(data: ConfigData = {}) {
    super();

    const noop = () => { },
      name = `form-textarea-${RpFormTextareaConfigModel.index++}`;

    this.defaults = {
      asyncValidators: [],
      autocomplete: '',
      classNames: '',
      dataType: 'text',
      disabled: false,
      errorMsgs: [],
      fieldId: name,
      fieldName: name,
      iconClass: '',
      maxlength: '',
      minheight: 200,
      minlength: '',
      modelOptions: { updateOn: 'blur' },
      onBlur: noop,
      onChange: noop,
      onFocus: noop,
      onKeyup: noop,
      pattern: /.*/,
      placeholder: '',
      prefix: '',
      readonly: false,
      required: false,
      size: '',
      suffix: '',
      trimInput: true,
      validators: []
    };

    this.updateData(data);
  }

  destroy(): void {
    this.data = undefined;
    this.defaults = undefined;
  }

  getState() {
    return {
      readonly: this.data.readonly,
      disabled: this.data.disabled
    };
  }

  onBlur() {
    this.data.onBlur();
  }

  onFocus() {
    this.data.onFocus();
  }

  onChange(data: any): void {
    this.data.onChange(data);
  }

  onKeyup() {
    this.data.onKeyup();
  }
}
