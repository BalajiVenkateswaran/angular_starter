import {
  Input,
  Directive,
  OnInit
} from '@angular/core';

import {
  AsyncValidator,
  FormControl,
  NG_ASYNC_VALIDATORS,
  ValidationErrors
} from '@angular/forms';

import { RpValidator } from '../../common/interfaces/validator.interface';
import { RpFormTextareaConfigModel as ConfigModel } from './form-textarea-config.model';

@Directive({
  selector: '[rpFormTextareaAsyncValidator]',
  providers: [
    {
      multi: true,
      provide: NG_ASYNC_VALIDATORS,
      useExisting: RpFormTextareaAsyncValidatorDirective
    }
  ]
})

export class RpFormTextareaAsyncValidatorDirective implements AsyncValidator, OnInit {
  @Input() rpFormTextareaAsyncValidator: ConfigModel;
  validators: RpValidator [];

  index = 0;
  control: FormControl;
  onValidationError: Function;
  onValidationComplete: Function;

  ctrlIsClean(): boolean {
    return !this.control.dirty;
  }

  ctrlIsInvalid(): boolean {
    return this.control.invalid;
  }

  ngOnInit() {
    this.validators = this.rpFormTextareaAsyncValidator.getAsyncValidators();
  }

  validate(c: FormControl): Promise<ValidationErrors | null> {
    this.reset();
    this.control = c;

    const promise = new Promise<ValidationErrors | null>((resolve, reject) => {
      this.onValidationError = reject;
      this.onValidationComplete = resolve;
    });

    this.callValidator();

    return promise;
  }

  callValidator() {
    if (this.ctrlIsInvalid() || this.ctrlIsClean() || this.index === this.validators.length) {
      this.onValidationComplete(null);
      this.rpFormTextareaAsyncValidator.resetErrorMsgs();
    } else {
      const value = this.control.value,
        validator = this.validators[this.index];
      validator.method(value).then(this.processValidationResult.bind(this));
    }
  }

  processValidationResult(valid: boolean) {
    const errorState = {};

    if (valid) {
      this.index++;
      this.callValidator();
    } else {
      const name = this.validators[this.index].name;
      errorState[name] = true;
      this.rpFormTextareaAsyncValidator.activateErrorMsg(name);
      this.onValidationComplete(errorState);
    }
  }

  reset() {
    this.index = 0;
    this.rpFormTextareaAsyncValidator.resetErrorMsgs();

    if (this.onValidationComplete) {
      this.onValidationComplete(null);
    }
  }
}
