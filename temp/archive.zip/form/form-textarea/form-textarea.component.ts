import {
  Component,
  OnInit,
  Input,
  ViewEncapsulation,
  OnDestroy
} from '@angular/core';
import { RpFormBaseComponent as BaseComponent } from '../form-common/form-base.component';
import { RpFormTextareaConfigModel as ConfigModel } from './form-textarea-config.model';
import { RpFormTextareaConfigData as ConfigData } from './form-textarea-config-data.interface';

@Component({
  selector: 'rp-form-textarea',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './form-textarea.component.html',
  styleUrls: ['./form-textarea.component.scss']
})

export class RpFormTextareaComponent extends BaseComponent implements OnInit, OnDestroy {
  config: ConfigModel;

  @Input('config') public set setConfig(data: ConfigData) {
    this.config.updateData(data);
  }

  constructor() {
    super();
    this.config = new ConfigModel();
  }

  getState() {
    return { ...super.getState(), ...this.config.getState() };
  }

  ngOnDestroy() {
    this.config.destroy();
    this.config = undefined;
  }

  ngOnInit() {
    this.state['has-error-msgs'] = this.config.hasErrorMsgs();
  }

  onBlur() {
    super.onBlur();
    this.config.onBlur();
  }

  onChange() {
    setTimeout(() => {
      super.emitChange();
      this.config.onChange(this.model);
    });
  }

  onFocus() {
    super.onFocus();
    this.config.onFocus();
  }

  onKeyup() {
    this.config.onKeyup();
  }
}
