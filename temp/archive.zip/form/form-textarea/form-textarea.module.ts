import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { RpFormTextareaComponent } from './form-textarea.component';
import { RpFormTextareaValidatorDirective } from './form-textarea-validator.directive';
import { RpFormTextareaAsyncValidatorDirective } from './form-textarea-async-validator.directive';

@NgModule({
  declarations: [
    RpFormTextareaAsyncValidatorDirective,
    RpFormTextareaComponent,
    RpFormTextareaValidatorDirective
  ],

  imports: [
    FormsModule,
    CommonModule
  ],

  exports: [
    RpFormTextareaComponent,
    RpFormTextareaValidatorDirective,
    RpFormTextareaAsyncValidatorDirective
  ]
})

export class RpFormTextareaModule { }
