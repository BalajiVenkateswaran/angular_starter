import { Directive, Input, OnInit } from '@angular/core';
import { NG_VALIDATORS } from '@angular/forms';
import { RpFormTextareaConfigModel as ConfigModel } from './form-textarea-config.model';
import { RpFormBaseValidator as BaseValidator } from '../form-common/form-base-validator.class';

@Directive({
  selector: '[rpFormTextareaValidator]',
  providers: [
    {
      multi: true,
      provide: NG_VALIDATORS,
      useExisting: RpFormTextareaValidatorDirective
    }
  ]
})

export class RpFormTextareaValidatorDirective extends BaseValidator implements OnInit {
  @Input('rpFormTextareaValidator') config: ConfigModel;

  ngOnInit() {
    this.validators = this.config.getValidators();
  }
}
