import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RpFormRadioComponent } from './form-radio.component';

@NgModule({
  declarations: [
    RpFormRadioComponent
  ],

  imports: [
    CommonModule,
    FormsModule
  ],

  exports: [
    RpFormRadioComponent
  ]
})

export class RpFormRadioModule { }
