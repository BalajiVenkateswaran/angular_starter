export interface RpFormRadioConfigData {
  classNames?: string;
  disabled?: boolean;
  fieldId?: string;
  fieldName?: string;
  labelLeft?: boolean;
  labelText?: string;
  readonly?: boolean;
  required?: boolean;
  value: any;
}
