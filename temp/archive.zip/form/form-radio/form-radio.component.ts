import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation,
  OnDestroy,
  ViewChild
} from '@angular/core';

import { RpFormRadioConfigModel as ConfigModel } from './form-radio-config.model';
import { RpFormRadioConfigData as ConfigData } from './form-radio-config-data.interface';
import { NgModel } from '@angular/forms';

@Component({
  selector: 'rp-form-radio',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './form-radio.component.html',
  styleUrls: ['./form-radio.component.scss']
})

export class RpFormRadioComponent implements OnInit, OnDestroy {
  config: ConfigModel;

  @Input() model: any;
  @Output() modelChange = new EventEmitter<any>();

  @Input('config') public set setConfig(data: ConfigData) {
    this.config.updateData(data);
  }

  @ViewChild('ctrl') ctrl: NgModel;

  constructor() {
    this.config = new ConfigModel();
  }

  getState() {
    const state = {
      dirty: this.ctrl.dirty,
      error: this.ctrl.invalid,
      touched: this.ctrl.touched,
      pending: this.ctrl.pending,
      disabled: this.ctrl.disabled
    };

    return { ...state, ...this.config.getState() };
  }

  ngOnInit() {

  }

  ngOnDestroy(): void {
    this.config.destroy();
    this.config = undefined;
  }

  onChange() {
    this.modelChange.emit(this.model);
  }
}
