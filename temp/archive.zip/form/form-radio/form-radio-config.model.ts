import { RpFormRadioConfigData } from './form-radio-config-data.interface';

export class RpFormRadioConfigModel {
  static index = 1;

  name: string;
  data: RpFormRadioConfigData;

  constructor(data?: RpFormRadioConfigData) {
    this.name = `form-radio-${RpFormRadioConfigModel.index++}`;
    this.updateData(data);
  }

  updateData(data?: RpFormRadioConfigData): void {
    const defaultData = {
      classNames: '',
      disabled: false,
      fieldId: this.name,
      fieldName: this.name,
      labelLeft: false,
      labelText: '',
      readonly: false,
      required: false,
      value: undefined
    };

    this.data = { ...defaultData, ...data };
  }

  destroy(): void {
    this.data = undefined;
  }

  getState(): {} {
    const state = {
      readonly: this.data.readonly
    };

    if (this.data.labelText) {
      if (this.data.labelLeft) {
        state['label-left'] = true;
      } else {
        state['label-right'] = true;
      }
    }

    return state;
  }
}
