import {
  Component,
  ViewEncapsulation,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { RpFormCheckboxConfigModel as ConfigModel } from './form-checkbox-config.model';
import { RpFormCheckboxConfigData as ConfigData } from './form-checkbox-config-data.interface';

@Component({
  selector: 'rp-form-checkbox',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './form-checkbox.component.html',
  styleUrls: ['./form-checkbox.component.scss']
})

export class RpFormCheckboxComponent {
  model: any;
  rawModel: any;
  value: boolean;
  config: ConfigModel;

  @Output() modelChange = new EventEmitter<any>();

  @Input('model') public set setModel(data: any) {
    this.rawModel = data;
    this.value = this.config.isTrueValue(data);
  }

  @Input('config') public set setConfig(data: ConfigData) {
    this.config.updateData(data);
    this.value = this.config.isTrueValue(this.rawModel);
  }

  constructor() {
    this.config = new ConfigModel();
  }

  getState() {
    return this.config.getState();
  }

  onChange() {
    if (this.value) {
      this.model = this.config.getTrueValue();
    } else {
      this.model = this.config.getFalseValue();
    }

    this.modelChange.emit(this.model);
  }
}
