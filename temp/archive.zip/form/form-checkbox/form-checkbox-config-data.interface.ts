export interface RpFormCheckboxConfigData {
  theme?: string;
  classNames?: string;
  disabled?: boolean;
  fieldId?: string;
  fieldName?: string;
  labelLeft?: boolean;
  labelText?: string;
  readonly?: boolean;
  required?: boolean;
  trueValue?: boolean;
  falseValue?: boolean;
}
