import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpFormCheckboxComponent } from './form-checkbox.component';

describe('FormCheckboxComponent', () => {
  let component: RpFormCheckboxComponent;
  let fixture: ComponentFixture<RpFormCheckboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpFormCheckboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpFormCheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
