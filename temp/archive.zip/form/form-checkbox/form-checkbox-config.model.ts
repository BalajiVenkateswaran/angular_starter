import { RpFormCheckboxConfigData as ConfigData } from './form-checkbox-config-data.interface';

export class RpFormCheckboxConfigModel {
  static index = 1;

  name: string;
  data: ConfigData;
  defaults: ConfigData;

  constructor(data: ConfigData = {}) {
    this.updateData(data);
    this.name = `form-checkbox-${RpFormCheckboxConfigModel.index++}`;
  }

  getFalseValue(): any {
    return this.data.falseValue;
  }

  getState() {
    const state = {
      disabled: this.data.disabled,
      readonly: this.data.readonly
    };

    if (this.data.classNames) {
      state[this.data.classNames] = true;
    }

    if (this.data.labelText) {
      if (this.data.labelLeft) {
        state['label-left'] = true;
      } else {
        state['label-right'] = true;
      }
    }

    state[this.getThemeClass()] = true;

    return state;
  }

  getThemeClass(): string {
    const themes = {
      switch: 'rp-switch',
      checkbox: 'rp-form-checkbox',
    };

    if (Object.keys(themes).indexOf(this.data.theme) === -1) {
      return themes.checkbox;
    }

    return themes[this.data.theme];
  }

  getTrueValue(): any {
    return this.data.trueValue;
  }

  isDisabled(): boolean {
    return this.data.disabled;
  }

  isRequired(): boolean {
    return this.data.required;
  }

  isTrueValue(data: any): boolean {
    return this.data.trueValue === data;
  }

  updateData(data: ConfigData = {}): void {
    this.defaults = {
      theme: 'checkbox',
      classNames: '',
      disabled: false,
      fieldId: this.name,
      fieldName: this.name,
      labelLeft: false,
      labelText: '',
      readonly: false,
      required: false,
      trueValue: true,
      falseValue: false
    };

    this.data = { ...this.defaults, ...data };
  }
}
