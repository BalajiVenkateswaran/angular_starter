import { RpFormCheckboxModule } from './form-checkbox.module';

describe('FormCheckboxModule', () => {
  let formCheckboxModule: RpFormCheckboxModule;

  beforeEach(() => {
    formCheckboxModule = new RpFormCheckboxModule();
  });

  it('should create an instance', () => {
    expect(formCheckboxModule).toBeTruthy();
  });
});
