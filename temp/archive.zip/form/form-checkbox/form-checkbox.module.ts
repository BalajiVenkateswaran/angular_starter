import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpFormCheckboxComponent } from './form-checkbox.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    RpFormCheckboxComponent
  ],

  imports: [
    CommonModule,
    FormsModule
  ],

  exports: [
    RpFormCheckboxComponent
  ]
})

export class RpFormCheckboxModule { }
