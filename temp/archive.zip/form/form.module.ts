import { NgModule } from '@angular/core';
import { RpFormCheckboxModule } from './form-checkbox/form-checkbox.module';
import { RpFormRadioModule } from './form-radio/form-radio.module';
import { RpFormSelectModule } from './form-select/form-select.module';
import { RpFormTextModule } from './form-text/form-text.module';
import { RpFormTextareaModule } from './form-textarea/form-textarea.module';

@NgModule({
  declarations: [
  ],

  imports: [
    RpFormCheckboxModule,
    RpFormRadioModule,
    RpFormSelectModule,
    RpFormTextModule,
    RpFormTextareaModule
  ],

  exports: [
    RpFormCheckboxModule,
    RpFormRadioModule,
    RpFormSelectModule,
    RpFormTextModule,
    RpFormTextareaModule
  ]
})

export class RpFormModule { }
