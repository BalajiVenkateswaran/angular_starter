import { RpValidator } from '../../common/interfaces/validator.interface';

export class RpFormBaseConfigModel {
  data: any;
  defaults: any;

  activateErrorMsg(name: string): void {
    this.data.errorMsgs.forEach((item: {active: boolean, name: string}) => {
      item.active = item.name === name;
    });
  }

  getAsyncValidators(): RpValidator[] {
    return this.data.asyncValidators;
  }

  getValidators(): RpValidator[] {
    return this.data.validators;
  }

  hasErrorMsgs(): boolean {
    return this.data.errorMsgs.length !== 0;
  }

  hasValidators(): boolean {
    return (this.data.validators.length + this.data.asyncValidators.length) !== 0;
  }

  isDisabled(): boolean {
    return this.data.disabled;
  }

  isRequired(): boolean {
    return this.data.required;
  }

  resetErrorMsgs(): void {
    this.data.errorMsgs.forEach((item: {active: boolean}) => {
      item.active = false;
    });
  }

  updateData(data): void {
    this.data = { ...{}, ...this.defaults, ...data };
  }
}
