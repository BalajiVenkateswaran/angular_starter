import { Validator, FormControl, ValidationErrors } from '@angular/forms';

import { RpValidator } from '../../common/interfaces/validator.interface';
import { RpFormBaseConfigModel } from './form-base-config.model';

export class RpFormBaseValidator implements Validator {
  config: RpFormBaseConfigModel;
  validators: RpValidator[];

  activateErrorMsg(name: string): void {
    this.config.activateErrorMsg(name);
  }

  isRequired(): boolean {
    return this.config.isRequired();
  }

  resetErrorMsgs(): void {
    this.config.resetErrorMsgs();
  }

  validate(c: FormControl): ValidationErrors {
    const notDirty = !c.dirty,
      noValidators = this.validators.length === 0,
      empty = c.value === '' && this.isRequired();

    this.resetErrorMsgs();

    if (empty || notDirty || noValidators) {
      return null;
    }

    return this.execValidators(c.value);
  }

  execValidators(value: any): any {
    let valid = true;
    const errorState = {};

    this.validators.forEach((validator) => {
      if (valid) {
        valid = validator.method(value);
        if (!valid) {
          errorState[validator.name] = true;
          this.activateErrorMsg(validator.name);
        }
      }
    });

    return valid ? null : errorState;
  }
}
