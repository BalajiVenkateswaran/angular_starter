import { NgModel } from '@angular/forms';
import { Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { RpValidationMsg } from '../../common/interfaces/validation-msg.interface';

export class RpFormBaseComponent {
  state: {} = {};

  @Output() modelChange = new EventEmitter<any>();

  @Input() model?: any;

  @ViewChild('ctrl') ctrl: NgModel;

  emitChange() {
    this.modelChange.emit(this.model);
  }

  errorIsActive(obj: RpValidationMsg): boolean {
    return !!(this.ctrl.errors && this.ctrl.errors[obj.name]);
  }

  getState() {
    const state = {
      dirty: this.ctrl.dirty,
      error: this.ctrl.invalid,
      touched: this.ctrl.touched,
      pending: this.ctrl.pending,
      disabled: this.ctrl.disabled
    };

    return { ...this.state, ...state, ...this.ctrl.errors };
  }

  onBlur() {
    this.state['focus'] = false;
  }

  onFocus() {
    this.state['focus'] = true;
  }

  onMouseover() {
    this.state['hover'] = true;
  }

  onMouseout() {
    this.state['hover'] = false;
  }
}
