import { RpFormTextConfigData as ConfigData } from './form-text-config-data.interface';
import { RpFormBaseConfigModel as BaseConfigModel } from '../form-common/form-base-config.model';

export class RpFormTextConfigModel extends BaseConfigModel {
  static index = 1;

  data: ConfigData;
  defaults: ConfigData;

  constructor(data: ConfigData = {}) {
    super();

    const noop = () => { },
      name = `form-text-${RpFormTextConfigModel.index++}`;

    this.defaults = {
      asyncValidators: [],
      autocomplete: '',
      classNames: '',
      dataType: 'text',
      disabled: false,
      errorMsgs: [],
      fieldId: name,
      fieldName: name,
      iconClass: '',
      maxlength: '',
      minlength: '',
      modelOptions: { updateOn: 'blur' },
      onBlur: noop,
      onChange: noop,
      onFocus: noop,
      onKeyup: noop,
      pattern: /.*/,
      placeholder: '',
      prefix: '',
      readonly: false,
      required: false,
      size: '',
      suffix: '',
      trimInput: true,
      validators: []
    };

    this.updateData(data);
  }

  destroy(): void {
    this.data = undefined;
    this.defaults = undefined;
  }

  getState() {
    return {
      readonly: this.data.readonly,
      disabled: this.data.disabled
    };
  }

  onBlur() {
    this.data.onBlur();
  }

  onFocus() {
    this.data.onFocus();
  }

  onChange(data: any): void {
    this.data.onChange(data);
  }

  onKeyup() {
    this.data.onKeyup();
  }
}
