import {
  Input,
  Directive,
  OnInit
} from '@angular/core';

import {
  AsyncValidator,
  FormControl,
  NG_ASYNC_VALIDATORS,
  ValidationErrors
} from '@angular/forms';
import { RpValidator } from '../../common/interfaces/validator.interface';
import { RpFormTextConfigModel as ConfigModel } from './form-text-config.model';

@Directive({
  selector: '[rpFormTextAsyncValidator]',
  providers: [
    {
      multi: true,
      provide: NG_ASYNC_VALIDATORS,
      useExisting: RpFormTextAsyncValidatorDirective
    }
  ]
})

export class RpFormTextAsyncValidatorDirective implements AsyncValidator, OnInit {
  @Input() rpFormTextAsyncValidator: ConfigModel;
  validators: RpValidator [];

  index = 0;
  control: FormControl;
  onValidationError: Function;
  onValidationComplete: Function;

  ctrlIsClean(): boolean {
    return !this.control.dirty;
  }

  ctrlIsInvalid(): boolean {
    return this.control.invalid;
  }

  ngOnInit() {
    this.validators = this.rpFormTextAsyncValidator.getAsyncValidators();
  }

  validate(c: FormControl): Promise<ValidationErrors | null> {
    this.reset();
    this.control = c;

    const promise = new Promise<ValidationErrors | null>((resolve, reject) => {
      this.onValidationError = reject;
      this.onValidationComplete = resolve;
    });

    this.callValidator();

    return promise;
  }

  callValidator() {
    if (this.ctrlIsInvalid() || this.ctrlIsClean() || this.index === this.validators.length) {
      this.onValidationComplete(null);
      this.rpFormTextAsyncValidator.resetErrorMsgs();
    } else {
      const value = this.control.value,
        validator = this.validators[this.index];
      validator.method(value).then(this.processValidationResult.bind(this));
    }
  }

  processValidationResult(valid: boolean) {
    const errorState = {};

    if (valid) {
      this.index++;
      this.callValidator();
    } else {
      const name = this.validators[this.index].name;
      errorState[name] = true;
      this.rpFormTextAsyncValidator.activateErrorMsg(name);
      this.onValidationComplete(errorState);
    }
  }

  reset() {
    this.index = 0;
    this.rpFormTextAsyncValidator.resetErrorMsgs();

    if (this.onValidationComplete) {
      this.onValidationComplete(null);
    }
  }
}
