import { Directive, Input, OnInit } from '@angular/core';
import { NG_VALIDATORS } from '@angular/forms';
import { RpFormTextConfigModel as ConfigModel } from './form-text-config.model';
import { RpFormBaseValidator as BaseValidator } from '../form-common/form-base-validator.class';

@Directive({
  selector: '[rpFormTextValidator]',
  providers: [
    {
      multi: true,
      provide: NG_VALIDATORS,
      useExisting: RpFormTextValidatorDirective
    }
  ]
})

export class RpFormTextValidatorDirective extends BaseValidator implements OnInit {
  @Input('rpFormTextValidator') config: ConfigModel;

  ngOnInit() {
    this.validators = this.config.getValidators();
  }
}
