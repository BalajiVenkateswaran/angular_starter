import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { RpFormTextComponent } from './form-text.component';
import { RpFormTextValidatorDirective } from './form-text-validator.directive';
import { RpFormTextAsyncValidatorDirective } from './form-text-async-validator.directive';

@NgModule({
  declarations: [
    RpFormTextAsyncValidatorDirective,
    RpFormTextComponent,
    RpFormTextValidatorDirective
  ],

  imports: [
    FormsModule,
    CommonModule
  ],

  exports: [
    RpFormTextComponent,
    RpFormTextValidatorDirective,
    RpFormTextAsyncValidatorDirective
  ]
})

export class RpFormTextModule { }
