import {
  Component,
  OnInit,
  Input,
  ViewEncapsulation,
  OnDestroy
} from '@angular/core';
import { RpFormBaseComponent as BaseComponent } from '../form-common/form-base.component';
import { RpFormTextConfigModel as ConfigModel } from './form-text-config.model';
import { RpFormTextConfigData as ConfigData } from './form-text-config-data.interface';

@Component({
  selector: 'rp-form-text',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './form-text.component.html',
  styleUrls: ['./form-text.component.scss']
})

export class RpFormTextComponent extends BaseComponent implements OnInit, OnDestroy {
  config: ConfigModel;

  @Input('config') public set setConfig(data: ConfigData) {
    this.config.updateData(data);
  }

  constructor() {
    super();
    this.config = new ConfigModel();
  }

  getState() {
    return { ...super.getState(), ...this.config.getState() };
  }

  ngOnDestroy() {
    this.config.destroy();
    this.config = undefined;
  }

  ngOnInit() {
    this.state['has-error-msgs'] = this.config.hasErrorMsgs();
  }

  onBlur() {
    super.onBlur();
    this.config.onBlur();
  }

  onChange() {
    setTimeout(() => {
      super.emitChange();
      this.config.onChange(this.model);
    });
  }

  onFocus() {
    super.onFocus();
    this.config.onFocus();
  }

  onKeyup() {
    this.config.onKeyup();
  }
}
