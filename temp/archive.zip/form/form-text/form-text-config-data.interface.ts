import { RpValidator } from '../../common/interfaces/validator.interface';
import { RpValidationMsg } from '../../common/interfaces/validation-msg.interface';

export interface RpFormTextConfigData {
  asyncValidators?: RpValidator [];
  autocomplete?: string;
  classNames?: string;
  dataType?: string;
  disabled?: boolean;
  errorMsgs?: RpValidationMsg [];
  fieldId?: string;
  fieldName?: string;
  iconClass?: string;
  maxlength?: string;
  minlength?: string;
  modelOptions?: { updateOn?: string };
  onBlur?: Function;
  onChange?: Function;
  onFocus?: Function;
  onKeyup?: Function;
  pattern?: RegExp;
  placeholder?: string;
  prefix?: string;
  readonly?: boolean;
  required?: boolean;
  size?: string;
  suffix?: string;
  trimInput?: boolean;
  validators?: RpValidator [];
}
