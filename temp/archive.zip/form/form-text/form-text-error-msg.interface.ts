export interface RpFormTextErrorMsgInterface {
  name: string;
  text: string;
  active?: boolean;
}
