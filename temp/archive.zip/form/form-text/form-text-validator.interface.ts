export interface RpFormTextValidatorData {
  name: string;
  method: Function;
}
