import { RpFormTextValidatorData } from './form-text-validator.interface';
import { RpFormTextErrorMsgInterface } from './form-text-error-msg.interface';

/**
 * @summary Interface for header user link
 * @description Enforces required and optional
 * keys for user link object
 */
export interface RpFormTextConfigData {
  asyncValidators?: RpFormTextValidatorData [];
  autocomplete?: string;
  classNames?: string;
  dataType?: string;
  disabled?: boolean;
  errorMsgs?: RpFormTextErrorMsgInterface [];
  fieldId?: string;
  fieldName?: string;
  iconClass?: string;
  maxlength?: string;
  minlength?: string;
  modelOptions?: { updateOn?: string };
  onBlur?: Function;
  onChange?: Function;
  onFocus?: Function;
  onKeyup?: Function;
  pattern?: RegExp;
  placeholder?: string;
  prefix?: string;
  readonly?: boolean;
  required?: boolean;
  size?: string;
  suffix?: string;
  trimInput?: boolean;
  validators?: RpFormTextValidatorData [];
}
