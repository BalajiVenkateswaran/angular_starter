import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpCopyContentComponent } from './copy-content/copy-content.component';

@NgModule({
  declarations: [
    RpCopyContentComponent
  ],

  imports: [
    CommonModule
  ],

  exports: [
    RpCopyContentComponent
  ]
})

export class RpCopyContentModule { }
