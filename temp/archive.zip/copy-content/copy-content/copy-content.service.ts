import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })

export class RpCopyContentService {
  private static instance: RpCopyContentService;

  copyMethod: Function;

  constructor() {
    this.copyMethod = () => {};
  }

  copyContent(text: string): void {
    this.copyMethod(text);
  }

  setCopyMethod(method: Function) {
    this.copyMethod = method;
  }
}
