import { Component, OnInit, ViewChild, ElementRef, Inject, ViewEncapsulation } from '@angular/core';
import { RpCopyContentService as CopySvc } from './copy-content.service';

@Component({
  selector: 'rp-copy-content',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './copy-content.component.html',
  styleUrls: ['./copy-content.component.scss']
})

export class RpCopyContentComponent implements OnInit {
  @ViewChild('clipboard') clipboard: ElementRef;

  constructor(
    private copySvc: CopySvc,
    @Inject('Window') private win: Window) { }

  copyContent(text: string): void {
    this.clipboard.nativeElement.value = text;
    this.clipboard.nativeElement.select();
    setTimeout(this.execCopy.bind(this), 100);
  }

  execCopy(): void {
    this.win.document.execCommand('copy');
    this.clipboard.nativeElement.value = '';
  }

  ngOnInit() {
    this.copySvc.setCopyMethod(this.copyContent.bind(this));
  }
}
