import { RpHeaderToolbarIconInterface as IconData } from './header-toolbar-icon.interface';

export class RpHeaderToolbarIcon {
  data: IconData;

  constructor(data: IconData) {
    const defaultData: IconData = {
      url: '',
      text: '',
      count: 0,
      event: '',
      active: false,
      className: '',
      method: () => { },
      appSwitcher: false
    };

    this.data = { ...defaultData, ...data };
  }

  getEventName(): string {
    return this.data.event;
  }

  hasEvent() {
    return this.data.event !== '';
  }

  isAppSwitcher() {
    return this.data.active && this.data.appSwitcher;
  }

  isLink(): boolean {
    return this.data.active && !!this.data.url;
  }

  isNotLink(): boolean {
    return this.data.active && !this.data.url && !this.data.appSwitcher;
  }

  isHelp(): boolean {
    return this.data.className === 'help';
  }
}
