import { RpHeaderToolbarIcon as Icon } from './header-toolbar-icon';
import { RpHeaderToolbarIconInterface as IconData } from './header-toolbar-icon.interface';

export class RpHeaderToolbarIcons {
  list: Icon[];

  constructor() {
    this.list = [];
  }

  setData(list: IconData[]) {
    this.list = [];

    list.forEach((iconData: IconData) => {
      this.list.push(new Icon(iconData));
    });
  }
}
