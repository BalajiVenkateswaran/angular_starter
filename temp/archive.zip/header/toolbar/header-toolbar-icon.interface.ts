export interface RpHeaderToolbarIconInterface {
  url?: string;
  text?: string;
  count?: number;
  event?: string;
  active?: boolean;
  method?: Function;
  className?: string;
  appSwitcher?: boolean;
}
