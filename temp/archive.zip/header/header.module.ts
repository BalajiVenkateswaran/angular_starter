import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { RpAppSwitcherComponent } from './app-switcher/app-switcher.component';
import { RpAppSwitcherIconConfig } from './app-switcher/app-switcher-icon-config';
import { RpAppSwitcherIconPipe } from './app-switcher/app-switcher-icon.pipe';
import { RpCollapseModule } from '../collapse/collapse.module';
import { RpCommonModule } from '../common/common.module';
import { RpEventsModule } from '../events/events.module';
import { RpFormModule } from '../form/form.module';
import { RpHeaderComponent } from './header/header.component';
import { RpSvgIconModule } from '../svg-icon/svg-icon.module';
import { RpTabsModule } from '../tabs/tabs.module';
import { RpToggleModule } from '../toggle/toggle.module';
import { svgIconConfig } from './app-switcher/svg-icon.config';
import { RpHeaderHelpService } from './header/header-help.service';
import { HeaderHelpConfig } from './header/header-help-data.config';

@NgModule({
  declarations: [
    RpHeaderComponent,
    RpAppSwitcherComponent,
    RpAppSwitcherIconPipe
  ],

  imports: [
    CommonModule,
    RouterModule,
    RpCollapseModule,
    RpCommonModule,
    RpEventsModule,
    RpFormModule,
    RpSvgIconModule,
    RpTabsModule,
    RpToggleModule
  ],

  exports: [
    RpHeaderComponent
  ],

  providers: [
    HeaderHelpConfig,
    RpHeaderHelpService,
    { provide: 'RpSvgIconConfig', useValue: svgIconConfig },
    { provide: 'RpAppSwitcherIconConfig', useValue: RpAppSwitcherIconConfig }
  ]
})

export class RpHeaderModule { }
