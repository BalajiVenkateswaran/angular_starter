import { RpAppSwitcherItemData as ItemData } from './app-switcher-item-data.interface';

export class RpAppSwitcherSolutionModel {
  data: ItemData;

  constructor(data: ItemData) {
    this.data = data || {};
  }

  getIconId(): string {
    return `prod${this.data.id}`;
  }

  getWinId(): string {
    return this.data.isNewTab ? `prod${this.data.id}` : undefined;
  }

  isFavorite(): boolean {
    return this.data.isFavorite;
  }
}
