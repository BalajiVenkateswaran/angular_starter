import { Pipe, PipeTransform, Inject } from '@angular/core';
import { RpLoggingService as LogSvc } from '../../common/services/logging.service';

@Pipe({
  name: 'appSwitcherIcon'
})

export class RpAppSwitcherIconPipe implements PipeTransform {
  constructor(
    private log: LogSvc,
    @Inject('RpAppSwitcherIconConfig') private config) {
  }

  transform(key: string): string {
    if (key && this.config[key]) {
      return this.config[key];
    }

    this.log.warn(`${key} does not have an icon defined in config`);
    return '';
  }
}
