import { Component, ViewEncapsulation, Input } from '@angular/core';

import { RpAppSwitcherModel } from './app-switcher.model';
import { RpAppSwitcherItemData as ItemData } from './app-switcher-item-data.interface';
import { RpTabData as TabData } from '../../tabs/tabs/tab-data.interface';

@Component({
  selector: 'rp-header-app-switcher',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './app-switcher.component.html',
  styleUrls: ['./app-switcher.component.scss']
})

export class RpAppSwitcherComponent {
  menuHidden = true;
  tabsList: TabData[];
  model: RpAppSwitcherModel;

  tabs: {
    all: TabData;
    fav: TabData;
  };

  @Input('data') public set setData(data: ItemData[]) {
    this.model.setData(data);

    if (this.model.hasFavorites()) {
      this.tabsList.forEach((item) => {
        item.active = item.id === 'fav';
      });
    }
  }

  constructor() {
    this.tabs = {
      all: {
        id: 'all',
        active: false,
        text: 'all products'
      },
      fav: {
        id: 'fav',
        active: true,
        text: 'favorites'
      }
    };

    this.model = new RpAppSwitcherModel();
    this.tabsList = Object.values(this.tabs);
  }
}
