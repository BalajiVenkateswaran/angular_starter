import { RpSvgIconConfigInterface } from '../../svg-icon/svg-icon/svg-icon-config.interface';

export const svgIconConfig: RpSvgIconConfigInterface = {
  path: 'assets/lib/svg-icon/images/'
};
