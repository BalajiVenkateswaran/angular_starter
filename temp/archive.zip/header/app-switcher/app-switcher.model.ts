import { RpAppSwitcherItemData as ItemData } from './app-switcher-item-data.interface';
import { RpAppSwitcherFamilyModel as Family } from './app-switcher-family.model';
import { RpAppSwitcherSolutionModel as Soln } from './app-switcher-solution.model';

export class RpAppSwitcherModel {
  favorites: Soln[];
  families: Family[];

  constructor() {
    this.families = [];
    this.favorites = [];
  }

  setData(list: ItemData[]): void {
    const store = {};

    list.forEach((data: ItemData) => {
      if (!data.name) {
        return;
      }

      const familyId = data.familyId,
        soln = new Soln(data),
        fam = store[familyId] ? store[familyId] : new Family(data);

      if (!store[familyId]) {
        store[familyId] = fam;
        this.families.push(fam);
      }

      if (soln.isFavorite()) {
        this.favorites.push(soln);
      }

      fam.addSoln(soln);
    });
  }

  hasFavorites(): boolean {
    return this.favorites.length > 0;
  }
}
