import { RpAppSwitcherItemData as ItemData } from './app-switcher-item-data.interface';
import { RpAppSwitcherSolutionModel as Soln } from './app-switcher-solution.model';

export class RpAppSwitcherFamilyModel {
  data: ItemData;
  solutions: Soln [];

  constructor(data: ItemData) {
    this.solutions = [];
    this.data = data || {};
  }

  addSoln(soln: Soln): void {
    this.solutions.push(soln);
  }

  getFamilyId(): string {
    return this.data.familyId.toString();
  }

  getIconId(): string {
    return `fam${this.data.familyId}`;
  }
}
