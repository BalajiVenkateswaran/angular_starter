export const RpAppSwitcherIconConfig = {
  'prod1': 'rpi-hq',                         //  OneSite
  'prod2': '',                               //  UnifiedUI
  'prod4': 'multi-chart',                    //  Asset Optimization
  'prod5': 'window-with-house',              //  Propertyware
  'prod6': 'chart-dollar',                   //  Lead2Lease
  'prod7': 'chart-with-star',                //  YieldStar
  'prod8': 'calculator-buttons',             //  RealPage Accounting
  'prod9': 'shield-star',                    //  Websites & Syndication (Marketing Center)
  'prod10': 'person-with-headset',           //  Prospect Contact Center
  'prod11': '',                              //  Social
  'prod12': '',                              //  Ops Bid
  'prod13': 'cart-with-dollar-sign',         //  Spend Management
  'prod14': 'briefcase-1',                   //  Client Portal
  'prod15': 'person-on-shield',              //  Renters Insurance
  'prod16': 'people-desk-dollar',            //  Vendor Services
  'prod17': 'monitor-with-user',             //  Resident Portal
  'prod18': 'bulb-1',                        //  Utility Management
  'prod19': 'monitor-with-graduation-cap',   //  Product Learning Portal
  'prod20': 'document-printer',              //  RealPage Document Management
  'prod21': '',                              //  OneSite Conversions
  'prod22': 'triangle-dots',                 //  OmniChannel
  'prod23': 'multi-house',                   //  OnSite
  'prod24': 'servers-with-magnifying-glass', //  Research Application - Blackbook
  'prod25': 'servers-with-pencil',           //  self-provisioning portal
  'prod26': 'window-with-blocks',            //  Unified Amenities
  'prod27': 'people-down-arrow',             //  Migration Tool
  'prod28': 'notepad-1',                     //  Product Updates

  'fam100': 'building-with-gear',
  'fam200': 'keyhole',
  'fam300': 'doc-gear',
  'fam400': 'multi-chart'
};
