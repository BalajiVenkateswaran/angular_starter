import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpAppSwitcherComponent } from './app-switcher.component';

describe('AppSwitcherComponent', () => {
  let component: RpAppSwitcherComponent;
  let fixture: ComponentFixture<RpAppSwitcherComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpAppSwitcherComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpAppSwitcherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
