export interface RpAppSwitcherItemData {
  id?: number;
  name?: string;
  url?: string;
  label?: string;
  familyId?: number;
  familyName?: string;
  isNewTab?: boolean;
  isFavorite?: boolean;
  isResource?: boolean;
}
