import { RpHeaderUserLinks as UserLinks } from '../user-links/user-links.model';
import { RpHeaderToolbarIcons as ToolbarIcons } from '../toolbar/header-toolbar-icons';
import { RpHeaderDefaultData as DefaultData} from 'src/lib/header/header/header-data-defaults';
import { RpHeaderDataInterface as HeaderData } from 'src/lib/header/header/header-data.interface';

import {
  RpAppSwitcherItemData as AppSwitcherItemData
} from '../app-switcher/app-switcher-item-data.interface';

export class RpHeaderModel {
  data: HeaderData;
  defaults: HeaderData;
  appSwitcherData: AppSwitcherItemData[];

  userLinks: UserLinks;
  toolbarIcons: ToolbarIcons;

  constructor() {
    this.appSwitcherData = [];
    this.defaults = DefaultData;

    this.userLinks = new UserLinks();
    this.toolbarIcons = new ToolbarIcons();

    this.setData();
  }

  setData(data?: HeaderData) {
    data = data || {};
    this.data = { ...this.defaults, ...data };
    this.userLinks.setData(this.data.userLinks);
    this.toolbarIcons.setData(this.data.toolbarIcons);
  }

  setAppSwitcherData(data?: AppSwitcherItemData[]) {
    this.appSwitcherData = data || [];
  }
}
