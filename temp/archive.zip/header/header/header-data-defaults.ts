import { RpHeaderDataInterface as HeaderData } from 'src/lib/header/header/header-data.interface';

export let RpHeaderDefaultData: HeaderData = {
  companyName: '',
  logoImgSrc: 'assets/lib/header/images/rp-logo-24x22.svg',
  logoLink: '',
  prodName: '',
  propertyName: '',
  searchEnabled: false,
  showNavToggle: false,
  toolbarIcons: [
    {
      active: true,
      text: 'Home',
      className: 'home',
    },

    {
      active: false,
      text: 'Help',
      className: 'help',
      event: 'help'
    }
  ],
  userInitials: '',
  userLinks: [
    {
      type: 'event',
      text: 'Sign out',
      event: 'signout'
    }
  ],
  userRole: '',
  username: ''
};
