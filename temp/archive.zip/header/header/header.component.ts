import {
  Component, ViewEncapsulation, ViewChild, ElementRef, Input, OnInit, Inject
} from '@angular/core';

import { RpHeaderModel } from './header.model';
import { PubSub } from '../../common/services/pubsub.service';
import { RpHeaderHelpService as HelpSvc } from './header-help.service';
import { RpHeaderToolbarIcon as Icon } from '../toolbar/header-toolbar-icon';
import { RpSessionStorageService as Storage } from '../../common/services/session-storage.service';
import { RpFormTextConfigData as TextConfig } from '../../form/form-text/form-text-config-data.interface';

import { RpAppSwitcherItemData as AppSwitcherItemData } from '../app-switcher/app-switcher-item-data.interface';

@Component({
  selector: 'rp-header',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class RpHeaderComponent implements OnInit {
  state: any;
  dark = false;
  navToggle = false;
  searchText: string;
  model: RpHeaderModel;
  searchActive = false;
  searchConfig: TextConfig;
  userLinksCollapsed = true;
  userLinksAsideOpen = false;
  propertyPickerVisible = false;
  userLinksCollapseDisabled = false;
  propertyPickerInitWatch: Function;
  propertyPickerToggleDisabled = true;

  @Input('data') public set setData(data: any) {
    if (data) {
      this.model.setData(data);
    }
  }

  @Input('appSwitcherData') public set setAppSwitcherData(data: AppSwitcherItemData[]) {
    if (data) {
      this.model.setAppSwitcherData(data);
    }
  }

  @ViewChild('propertyPickerToggle') propPickToggle: ElementRef;

  constructor(
    private pubsub: PubSub,
    private storage: Storage,
    private helpSvc: HelpSvc,
    @Inject('Window') private win) {
    this.model = new RpHeaderModel();

    this.searchConfig = {
      placeholder: 'Search',
      iconClass: 'fa fa-search',
      classNames: 'medium rounded-corners'
    };

    const initEvt = 'propertyPicker.init',
      initEvtCb = this.onPropertyPickerInit.bind(this);

    this.state = {};
    this.propertyPickerInitWatch = this.pubsub.subscribe(initEvt, initEvtCb);
  }

  ngOnInit() {
    if (this.storage.has('RpNav')) {
      const navState = this.storage.get('RpNav');

      if (navState.expanded) {
        setTimeout(() => {
          this.navToggle = navState.expanded;
        }, 500);
      }
    }
  }

  onNavToggle(data): void {
    this.pubsub.publish('rpNav.toggle', data);
  }

  onPropertyPickerInit(): void {
    this.propertyPickerToggleDisabled = false;
  }

  onSearchChange(): void {
    if (this.searchActive) {
      this.state['search-transition'] = true;

      setTimeout(() => {
        this.state['search-transition'] = false;
        this.state['search-active'] = true;
      }, 200);
    } else {
      this.state['search-active'] = false;
      this.state['search-transition'] = true;

      setTimeout(() => {
        this.state['search-transition'] = false;
      });
    }
  }

  onToolbarIconClick(icon: Icon) {
    if (icon.isHelp()) {
      this.helpSvc.show();
    } else if (icon.hasEvent()) {
      this.pubsub.publish(icon.getEventName());
    }
  }

  onWinSizeChange() {
    this.userLinksCollapsed = this.win.innerWidth >= 576;
    this.userLinksCollapseDisabled = this.win.innerWidth < 576;

    if (this.win.innerWidth > 991) {
      this.searchActive = false;
      this.state['search-active'] = false;
      this.state['search-transition'] = false;
    }
}

  publishNavTheme(data): void {
    this.pubsub.publish('rpNav.darkTheme', data);
  }

  togglePropertyPicker(): void {
    this.pubsub.publish('propertyPicker.toggleMenu', {
      visible: this.propertyPickerVisible,
      left: this.propPickToggle.nativeElement.offsetLeft,
      top: this.propPickToggle.nativeElement.offsetHeight
    });
  }
}
