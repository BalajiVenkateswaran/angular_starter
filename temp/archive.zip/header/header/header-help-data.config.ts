import { Provider } from '@angular/core';
import { RpHeaderHelpConfigInterface as ConfigData } from './header-help-config-data.interface';

export const config: ConfigData[] = [
  {
    vr: '40',
    pg: 'home',
    exp: /^\/$/,
    scrVer: '350',
    cs: '00000000000000000000000000000000000000000000000000001000000000000000000000000000000000000',
    context: {
      productAccess: {
        pg: 'ulAddUserProductAccess'
      }
    }
  }
];

export let HeaderHelpConfig: Provider = {
  useValue: config,
  provide: 'RpHeaderHelpConfig'
};
