import { Router } from '@angular/router';
import { Injectable, Inject } from '@angular/core';
import { RpLoggingService as LogSvc } from 'src/lib/common/services/logging.service';

@Injectable()

export class RpHeaderHelpService {
  keys: any;
  helpUrl: string;

  constructor(
    private router: Router,
    private logSvc: LogSvc,
    @Inject('Window') private win,
    @Inject('RpHeaderHelpConfig') private helpData) {
    this.keys = [
      {
        name: 'helpUrl',
        prefix: ''
      },
      {
        name: 'pg',
        prefix: '?pg='
      },
      {
        name: 'vr',
        prefix: '&vr='
      },
      {
        name: 'scrVer',
        prefix: '&scrVer='
      },
      {
        name: 'cs',
        prefix: '&cs='
      }
    ];

    this.helpUrl = 'http://devhelp.onesitedev.realpage.com/OneSiteHTMLHelp/budgeting/40/index.asp';
  }

  getHelpUrl(data: any): string {
    const reqd = [
      'helpUrl',
      'pg',
      'vr',
      'scrVer'
    ];

    data.helpUrl = this.helpUrl;

    return this.keys.reduce((str, key) => {
      if (data[key.name]) {
        str += key.prefix + data[key.name];
      }

      return str;
    }, '');
  }

  setHelpUrl(url: string): void {
    this.helpUrl = url;
  }

  show(): void {
    let helpUrl = '';
    const url = this.router.url;

    this.helpData.forEach((item) => {
      if (url.match(item.exp)) {
        helpUrl = this.getHelpUrl(item);
      }
    });

    if (helpUrl) {
      this.win.open(helpUrl, '_blank');
    } else {
      this.logSvc.warn('HeaderHelpSvc: Unable to find help data for ' + url);
    }
  }
}
