export interface RpHeaderHelpConfigInterface {
  vr: string;
  pg: string;
  scrVer: string;
  cs: string;
  exp: RegExp;
  context: {
    [text: string]: {
      pg: string;
    };
  };
}
