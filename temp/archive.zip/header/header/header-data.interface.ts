import {
  RpHeaderToolbarIconInterface as ToolbarIcon
} from 'src/lib/header/toolbar/header-toolbar-icon.interface';

import {
  RpHeaderUserLinkDataInterface as UserLink
} from 'src/lib/header/user-links/user-link.interface';

export interface RpHeaderDataInterface {
  companyName?: string;
  logoImgSrc?: string;
  logoLink?: string;
  prodName?: string;
  propertyName?: string;
  searchEnabled?: boolean;
  showNavToggle?: boolean;
  toolbarIcons?: ToolbarIcon[];
  userInitials?: string;
  userLinks?: UserLink[];
  userRole?: string;
  username?: string;
}
