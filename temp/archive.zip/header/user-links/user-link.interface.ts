/**
 * @summary Interface for header user link
 * @description Enforces required and optional
 * keys for user link object
 */
export interface RpHeaderUserLinkDataInterface {
  url?: string;
  type: string;
  text: string;
  event?: string;
  newWindow?: boolean;
}
