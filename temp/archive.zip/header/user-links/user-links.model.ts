import { RpHeaderUserLinkDataInterface as LinkData } from './user-link.interface';

export class RpHeaderUserLinks {
  links: LinkData [];

  constructor() {
    this.links = [];
  }

  setData(links: LinkData[]) {
    this.links = links;
  }

  invoke(data: any) {
    console.log('invoke link:', data);
  }
}
