import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpCollapseComponent } from './collapse/collapse.component';

@NgModule({
  declarations: [
    RpCollapseComponent
  ],

  imports: [
    CommonModule
  ],

  exports: [
    RpCollapseComponent
  ]
})

export class RpCollapseModule { }
