import {
  Component,
  Input,
  ElementRef,
  AfterContentInit,
  ViewEncapsulation,
  ViewChild
} from '@angular/core';

@Component({
  selector: 'rp-collapse',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './collapse.component.html',
  styleUrls: ['./collapse.component.scss']
})

export class RpCollapseComponent implements AfterContentInit {
  timer: any;
  height: number;

  state: {
    ready: boolean,
    expanded: boolean,
    collapsed: boolean
  };

  style: {
    'height.px': number
  };

  @ViewChild('content') content: ElementRef;

  @Input('ready') public set ready(b: boolean) {
    if (this.state.ready === true) {
      return;
    }

    this.state.ready = b;

    if (b === true) {
      this.delayRecordHeight();
    }
  }

  @Input('collapsed') public set collapsed(v: boolean) {
    this.state.collapsed = v;
    this.state.expanded = !v;

    if (this.state.ready === undefined) {
      this.initHeight();
    } else {
      this.toggle();
    }
  }

  @Input() disabled: boolean;

  constructor(private elem: ElementRef) {
    this.style = {
      'height.px': undefined
    };

    this.state = {
      expanded: false,
      collapsed: true,
      ready: undefined
    };
  }

  delayRecordHeight(): void {
    setTimeout(this.recordHeight.bind(this), 50);
  }

  ngAfterContentInit(): void {
    if (this.state.ready === undefined) {
      this.state.ready = true;
      this.initHeight().delayRecordHeight();
    }
  }

  initHeight(): RpCollapseComponent {
    this.style['height.px'] = this.state.expanded ? undefined : 0;
    return this;
  }

  recordHeight(): void {
    this.height = this.content.nativeElement.scrollHeight;
  }

  toggle(): void {
    clearTimeout(this.timer);

    if (this.disabled) {
      return;
    } else if (this.state.expanded) {
      this.style['height.px'] = this.height;
      this.timer = setTimeout(() => {
        this.style['height.px'] = undefined;
      }, 300);
    } else {
      this.recordHeight();
      this.style['height.px'] = this.height;
      setTimeout(() => {
        this.style['height.px'] = 0;
      });
    }
  }
}
