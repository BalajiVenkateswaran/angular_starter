export class RpAccordionPanelModel {
  theme: string;
  itemOpen: boolean;

  constructor() {

  }

  close(): void {
    this.itemOpen = false;
  }

  isOpen(): boolean {
    return this.itemOpen;
  }

  open(): void {
    this.itemOpen = true;
  }

  setOpen(open: boolean): void {
    this.itemOpen = open;
  }

  setTheme(theme: string): void {
    this.theme = theme;
  }

  toggle(): void {
    this.itemOpen = !this.itemOpen;
  }
}
