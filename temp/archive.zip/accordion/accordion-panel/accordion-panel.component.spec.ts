import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpAccordionPanelComponent } from './accordion-panel.component';

describe('AccordionItemComponent', () => {
  let component: RpAccordionPanelComponent;
  let fixture: ComponentFixture<RpAccordionPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpAccordionPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpAccordionPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
