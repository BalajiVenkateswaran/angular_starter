import {
  Component,
  OnInit,
  Input,
  ElementRef,
  ViewEncapsulation,
  ViewChild,
  AfterContentInit} from '@angular/core';
import { RpAccordionModel } from '../accordion/accordion.model';
import { RpAccordionPanelModel } from './accordion-panel.model';

@Component({
  selector: 'rp-accordion-panel',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './accordion-panel.component.html',
  styleUrls: ['./accordion-panel.component.scss']
})

export class RpAccordionPanelComponent implements OnInit, AfterContentInit {
  ready: boolean;
  toggle: HTMLElement;
  toggleHeight: number;
  content: HTMLElement;
  contentHeight: number;
  model: RpAccordionPanelModel;

  @Input() open: boolean;

  @ViewChild('content') contentElem: ElementRef;

  constructor(private accordionModel: RpAccordionModel) {
    this.model = new RpAccordionPanelModel;
  }

  getCollapsedHeight(): number {
    return this.toggleHeight;
  }

  getStyle(): object {
    const height = this.toggleHeight + this.contentHeight;

    return {
      'height.px': this.model.isOpen() ? height : this.toggleHeight
    };
  }

  getState(): object {
    return {
      ready: this.ready,
      collapsed: !this.model.isOpen()
    };
  }

  ngOnInit(): void {
    this.model.setOpen(this.open);
    this.accordionModel.registerItem(this.model);
  }

  ngAfterContentInit(): void {
    setTimeout(() => {
      this.ready = true;
      this.toggle = this.contentElem.nativeElement.children[0];
      this.content = this.contentElem.nativeElement.children[1];
      this.toggleHeight = this.toggle.offsetHeight;
      this.contentHeight = this.content.offsetHeight;
    });
  }

  toggleItem($event): void {
    if ($event.layerY < this.toggleHeight) {
      if (this.model.isOpen()) {
        this.contentHeight = this.content.offsetHeight;
      }
      this.accordionModel.toggleItem(this.model);
    }
  }
}
