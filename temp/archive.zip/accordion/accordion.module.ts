import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RpAccordionComponent } from './accordion/accordion.component';
import { RpAccordionPanelComponent } from './accordion-panel/accordion-panel.component';

@NgModule({
  declarations: [
    RpAccordionComponent,
    RpAccordionPanelComponent
  ],

  imports: [
    CommonModule
  ],

  exports: [
    RpAccordionComponent,
    RpAccordionPanelComponent,
  ]
})

export class RpAccordionModule { }
