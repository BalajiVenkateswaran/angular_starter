import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpAccordionComponent } from './accordion.component';

describe('AccordionComponent', () => {
  let component: RpAccordionComponent;
  let fixture: ComponentFixture<RpAccordionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpAccordionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpAccordionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
