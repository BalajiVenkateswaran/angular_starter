import { RpAccordionPanelModel } from '../accordion-panel/accordion-panel.model';

export class RpAccordionModel {
  theme: string;
  cascade = true;
  items: RpAccordionPanelModel [];

  constructor() {
    this.items = [];
  }

  closeAll() {
    this.items.forEach((item) => {
      item.close();
    });
  }

  openAll() {
    this.items.forEach((item) => {
      item.open();
    });
  }

  registerItem(item: RpAccordionPanelModel): void {
    this.items.push(item);
    item.setTheme(this.theme);
  }

  removeItem(accordionItem: RpAccordionPanelModel): void {
    this.items = this.items.filter((item) => {
      return item !== accordionItem;
    });
  }

  setCascade(bool: boolean): RpAccordionModel {
    if (typeof bool === 'boolean') {
      this.cascade = bool;
    }
    return this;
  }

  setTheme(theme: string): RpAccordionModel {
    this.theme = theme;
    return this;
  }

  toggleItem(accordionItem: RpAccordionPanelModel): void {
    accordionItem.toggle();

    if (this.cascade) {
      this.items.forEach((item) => {
        if (item !== accordionItem) {
          item.close();
        }
      });
    }
  }
}
