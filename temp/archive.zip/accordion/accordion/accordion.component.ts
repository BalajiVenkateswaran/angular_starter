import {
  Component,
  ViewEncapsulation,
  Input,
  OnChanges,
  OnInit} from '@angular/core';
import { RpAccordionModel } from './accordion.model';

@Component({
  selector: 'rp-accordion',
  providers: [RpAccordionModel],
  encapsulation: ViewEncapsulation.None,
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.scss']
})

export class RpAccordionComponent implements OnChanges, OnInit {
  prevAll = false;
  @Input() all: boolean;
  @Input() theme: string;
  @Input() cascade: boolean;

  constructor(private model: RpAccordionModel) { }

  ngOnChanges() {
    if (this.all !== this.prevAll) {
      if (this.all === true) {
        this.model.openAll();
      } else if (this.all === false) {
        this.model.closeAll();
      }
      this.prevAll = this.all;
    }
  }

  ngOnInit() {
    this.model
      .setTheme(this.theme)
      .setCascade(this.cascade);
  }
}
