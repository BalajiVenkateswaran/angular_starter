import { Provider } from '@angular/core';
import { RpPageTitleConfigData } from './page-title-config-data.interface';

export const config: RpPageTitleConfigData = {
  appName: 'Starter',

  sections: [
    {
      pages: [
        {
          url: /^\/$/,
          title: 'Home'
        }
      ]
    }
  ]
};

export let PageTitleConfig: Provider = {
  useValue: config,
  provide: 'RpPageTitleConfig'
};
