export interface RpPageTitlePageData {
  url: RegExp;
  title: string;
}

export interface RpPageTitleSectionData {
  sectionName?: string;
  pages: RpPageTitlePageData[];
}

export interface RpPageTitleConfigData {
  appName?: string;
  sections: RpPageTitleSectionData[];
}

export interface RpPageTitlePartsData {
  appName: string;
  pageTitle: string;
  sectionName: string;
}
