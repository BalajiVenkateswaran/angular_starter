import { Inject, Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { NavigationStart, Router } from '@angular/router';
import {
  RpPageTitleConfigData as Config,
  RpPageTitlePageData as PageData,
  RpPageTitleSectionData as SectionData,
  RpPageTitlePartsData as Parts
} from './page-title-config-data.interface';

@Injectable()

export class RpPageTitleService {
  event: any;
  pageData: PageData;

  constructor(
    private title: Title,
    private router: Router,
    @Inject('RpPageTitleConfig') private config: Config) {
    this.router.events.subscribe(this.onRouteChange.bind(this));
  }

  examinePage(section: SectionData, page: PageData): void {
    if (!this.pageData && this.event.url.match(page.url)) {
      this.pageData = page;

      this.setTitle({
        pageTitle: page.title,
        appName: this.config.appName,
        sectionName: section.sectionName
      });
    }
  }

  examineSection(section: SectionData): void {
    if (this.pageData) {
      return;
    }

    section.pages.forEach((page: PageData) => {
      this.examinePage(section, page);
    });
  }

  onRouteChange(e): void {
    if (e instanceof NavigationStart) {
      this.updatePageTitle(e);
    }
  }

  setTitle(parts: Parts): void {
    const list = [];

    if (parts.appName) {
      list.push(parts.appName);
    }

    if (parts.sectionName) {
      list.push(parts.sectionName);
    }

    list.push(parts.pageTitle);

    this.title.setTitle(list.join(' - '));
  }

  updatePageTitle(e): void {
    const examine = this.examineSection.bind(this);
    this.event = e;
    this.pageData = undefined;
    this.config.sections.forEach(examine);
  }
}
