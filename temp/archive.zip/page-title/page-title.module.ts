import { NgModule } from '@angular/core';
import { PageTitleConfig } from './page-title/page-title-config';
import { RpPageTitleService } from './page-title/page-title.service';

@NgModule({
  declarations: [

  ],

  imports: [

  ],

  exports: [

  ],

  providers: [
    PageTitleConfig,
    RpPageTitleService
  ]
})

export class RpPageTitleModule { }
