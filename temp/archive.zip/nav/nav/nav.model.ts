import { Injectable } from '@angular/core';

import {
  RpNavLinkDataInterface as LinkData,
  RpNavItemDataInterface as NavItemData
} from './nav-item-data.interface';

@Injectable({
  providedIn: 'root'
})

export class RpNavModel {
  static instance: RpNavModel;

  menuState: any;
  expanded = false;
  darkTheme = false;
  navItems: NavItemData[];

  constructor() {
    if (RpNavModel.instance) {
      return RpNavModel.instance;
    }

    this.navItems = [];

    this.menuState = {
      expanded: false,
      activeItems: [],
      darkTheme: false
    };

    RpNavModel.instance = this;
  }

  activateLink(url: string): void {
    this.navItems.forEach((group: NavItemData) => {
      group.active = false;

      if (group.labelLink && group.labelLink === url) {
        group.active = true;
      } else {
        this.activateSubmenuLink(group, url);
      }
    });
  }

  activateSubmenuLink(group: NavItemData, url: string): void {
    if (group.submenu && group.submenu.links) {
      let found = false;

      group.submenu.links.forEach((link: LinkData) => {
        link.active = link.labelLink === url;

        if (link.active) {
          found = true;
        }
      });

      group.active = found;
    }
  }

  getMenuState() {
    return this.menuState;
  }

  getState() {
    return {
      'dark-nav-theme': this.menuState.darkTheme,
      'rp-nav-expanded': this.menuState.expanded,
      'rp-nav-collapsed': !this.menuState.expanded
    };
  }

  initMenuState(data: any): void {
    this.menuState = { ...this.menuState, ...data };
  }

  isCollapsed() {
    return !this.menuState.expanded;
  }

  recordMenuState(menu) {
    if (menu.collapsed) {
      this.menuState.activeItems = this.menuState.activeItems.filter((item) => {
        return item !== menu.labelText;
      });
    } else {
      this.menuState.activeItems.push(menu.labelText);
    }
  }

  toggle() {
    this.menuState.expanded = !this.menuState.expanded;
  }

  updateData(data) {
    this.navItems = data;

    this.navItems.forEach((item) => {
      if (this.menuState.activeItems.indexOf(item.labelText) !== -1) {
        item.collapsed = false;
      }
    });
  }

  updateTheme(darkTheme: boolean): void {
    this.menuState.darkTheme = darkTheme;
  }
}
