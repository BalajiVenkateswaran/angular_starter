import { Router, NavigationStart } from '@angular/router';
import { Component, ViewEncapsulation, Inject, Input } from '@angular/core';

import { RpNavModel as Model } from './nav.model';
import { PubSub } from 'src/lib/common/services/pubsub.service';
import { RpNavItemDataInterface as NavItemData } from './nav-item-data.interface';
import { RpSessionStorageService as Storage } from 'src/lib/common/services/session-storage.service';

@Component({
  selector: 'rp-nav',
  styleUrls: ['./nav.component.scss'],
  templateUrl: './nav.component.html',
  encapsulation: ViewEncapsulation.None
})

export class RpNavComponent {
  model: Model;
  currentUrl: string;

  @Input('data') public set setData(data: NavItemData[]) {
    if (data) {
      this.model.updateData(data);
      this.model.activateLink(this.currentUrl);
    }
  }

  constructor(
    private pubsub: PubSub,
    private router: Router,
    private storage: Storage,
    @Inject('Window') private win) {
    this.model = new Model();

    const toggle = this.toggle.bind(this),
      onRouteChange = this.onRouteChange.bind(this),
      updateTheme = this.model.updateTheme.bind(this.model);

    this.initMenuState();
    this.router.events.subscribe(onRouteChange);
    this.pubsub.subscribe('rpNav.toggle', toggle);
    this.pubsub.subscribe('rpNav.darkTheme', updateTheme);
  }

  activateLink(url: string): void {
    this.currentUrl = url;
    this.model.activateLink(url);
  }

  initMenuState(): void {
    if (this.storage.has('RpNav')) {
      this.model.initMenuState(this.storage.get('RpNav'));
    }
  }

  onRouteChange(evt): void {
    if (evt instanceof NavigationStart) {
      this.activateLink(evt.url);
    }
  }

  recordMenuState(menu: any) {
    this.model.recordMenuState(menu);
    this.storeState();
  }

  storeState(): void {
    this.storage.set('RpNav', this.model.getMenuState());
  }

  toggle(): void {
    this.model.toggle();
    this.storeState();
  }
}
