import {
  Inject,
  Directive,
  ElementRef,
  ContentChild,
  AfterContentInit
} from '@angular/core';
import { RpNavModel } from './nav.model';

@Directive({
  exportAs: 'navItem',
  selector: '[rpNavItem]'
})

export class RpNavItemDirective implements AfterContentInit {
  timer: any;
  height: number;
  menuHeight: number;

  @ContentChild('navItemMenu') menu: ElementRef;

  constructor(
    private nav: RpNavModel,
    private elem: ElementRef,
    @Inject('Window') private win) { }

  getStyle() {
    return {
      'maxHeight.px': this.height
    };
  }

  ngAfterContentInit() {
    if (this.menu) {
      this.menuHeight = this.menu.nativeElement.scrollHeight;
    }
  }

  setHeight() {
    clearTimeout(this.timer);

    if (this.menu && this.nav.isCollapsed()) {
      const winHt = this.win.innerHeight,
        elemHt = this.elem.nativeElement.offsetHeight,
        offsetTop = this.elem.nativeElement.offsetTop;
      this.height = winHt - offsetTop - elemHt;
    }
  }

  unsetHeight() {
    this.timer = setTimeout(() => {
      this.height = undefined;
    }, 700);
  }
}
