export interface RpNavLinkDataInterface {
  active?: boolean;
  labelText?: string;
  labelLink?: string;
}

export interface RpNavSubmenuInterface {
  links?: RpNavLinkDataInterface[];
}

export interface RpNavItemDataInterface {
  active?: boolean;
  collapsed?: boolean;
  labelText?: string;
  labelLink?: string;
  iconClassName?: string;
  submenu?: RpNavSubmenuInterface;
}
