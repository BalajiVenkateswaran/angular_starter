import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpNavComponent } from './nav.component';

describe('NavComponent', () => {
  let component: RpNavComponent;
  let fixture: ComponentFixture<RpNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
