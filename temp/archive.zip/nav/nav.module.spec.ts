import { RpNavModule } from './nav.module';

describe('NavModule', () => {
  let navModule: RpNavModule;

  beforeEach(() => {
    navModule = new RpNavModule();
  });

  it('should create an instance', () => {
    expect(navModule).toBeTruthy();
  });
});
