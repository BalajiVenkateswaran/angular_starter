import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { RpCollapseModule } from '../collapse/collapse.module';
import { RpEventsModule } from '../events/events.module';
import { RpNavComponent } from './nav/nav.component';
import { RpNavItemDirective } from './nav/nav-item.directive';
import { RpToggleModule } from '../toggle/toggle.module';

@NgModule({
  declarations: [
    RpNavComponent,
    RpNavItemDirective
  ],

  imports: [
    RouterModule,
    CommonModule,
    RpEventsModule,
    RpToggleModule,
    RpCollapseModule
  ],

  exports: [
    RpNavComponent,
    RpNavItemDirective
  ]
})

export class RpNavModule { }
