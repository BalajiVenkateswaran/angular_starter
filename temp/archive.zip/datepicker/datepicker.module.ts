import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RpEventsModule } from '../events/events.module';
import { RpDatepickerComponent } from './datepicker/datepicker.component';
import { RpDatepickerPanelComponent } from './datepicker-panel/datepicker-panel.component';

@NgModule({
  declarations: [
    RpDatepickerComponent,
    RpDatepickerPanelComponent
  ],

  imports: [
    FormsModule,
    CommonModule,
    RpEventsModule
  ],

  exports: [
    RpDatepickerComponent,
    RpDatepickerPanelComponent
  ],

  providers: [

  ],

  entryComponents: [
    RpDatepickerPanelComponent
  ]
})

export class RpDatepickerModule { }
