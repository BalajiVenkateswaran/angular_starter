import { Moment } from 'moment';
import * as moment from 'moment';
import { RpValidator } from '../../common/interfaces/validator.interface';
import { RpDatepickerConfigData as ConfigData } from './datepicker-config-data.interface';

export class RpDatepickerConfigModel {
  static index = 1;

  data: ConfigData;
  defaults: ConfigData;
  weekDays: string[];

  constructor() {
    const index = RpDatepickerConfigModel.index++,
      name = `rp-datepicker-${index}`,
      wrapId = `rp-datepicker-wrap-${index}`;

    this.defaults = {
      dayIsDisabled: undefined,
      disabled: false,
      displayFormat: 'MM/DD/YYYY',
      errorMsgs: [],
      fieldID: name,
      fieldName: name,
      maxDate: undefined,
      minDate: undefined,
      parentId: '',
      placeholder: '',
      readonly: false,
      required: false,
      validators: [],
      wrapId: wrapId
    };

    this.data = { ...this.defaults };
  }

  activateErrorMsg(name?: string): void {
    this.data.errorMsgs.forEach((item) => {
      item.active = item.name === name;
    });
  }

  allowNext(day: Moment): boolean {
    if (this.data.maxDate) {
      return day.isBefore(this.data.maxDate);
    }

    return true;
  }

  allowPrev(day: Moment): boolean {
    if (this.data.minDate) {
      return day.isAfter(this.data.minDate);
    }

    return true;
  }

  format(data: Moment): string {
    return data.format(this.data.displayFormat);
  }

  genMoment(data: string): Moment {
    return moment(data, this.data.displayFormat);
  }

  genWeekDays(): void {
    const weekDay = moment().day(0);

    this.weekDays = [];

    for (let i = 0; i < 7; i++) {
      this.weekDays.push(weekDay.format('dd'));
      weekDay.add(1, 'day');
    }
  }

  getDisplayFormat(): string {
    return this.data.displayFormat;
  }

  getDisplayValue(data: Moment): string {
    return data.format(this.data.displayFormat);
  }

  getMaxLength(): number {
    return this.getDisplayFormat().length;
  }

  getModel(data: string): Moment {
    return moment(data, this.data.displayFormat);
  }

  getParentId(): string {
    return this.data.parentId ? this.data.parentId : this.data.wrapId;
  }

  getValidators(): RpValidator[] {
    return this.data.validators;
  }

  getWeekDays(): string[] {
    return this.weekDays;
  }

  hasErrorMsgs(): boolean {
    return this.data.errorMsgs.length > 0;
  }

  isAllowed(day: Moment): boolean {
    return !this.isDisabledItem(day);
  }

  isAllowedRange(range: any): boolean {
    let afterMin = false,
      beforeMax = false,
      containsMax = false,
      containsMin = false;

    const max = this.data.maxDate,
      min = this.data.minDate;

    if (min) {
      afterMin = range.start.isAfter(min);
      containsMin = range.start.isBefore(min) && range.end.isAfter(min);
    }

    if (max) {
      beforeMax = range.end.isBefore(max);
      containsMax = range.start.isBefore(max) && range.end.isAfter(max);
    }

    if (min && max) {
      return containsMax || containsMin || (beforeMax && afterMin);
    } else if (min) {
      return containsMin || afterMin;
    } else if (max) {
      return containsMax || beforeMax;
    }

    return true;
  }

  isDisabled() {
    return this.data.disabled;
  }

  isDisabledItem(day: Moment): boolean {
    let disabled = false;

    if (this.data.dayIsDisabled) {
      disabled = disabled || this.data.dayIsDisabled(day);
    }

    if (!disabled && this.data.minDate) {
      disabled = disabled || day.isBefore(this.data.minDate);
    }

    if (!disabled && this.data.maxDate) {
      disabled = disabled || day.isAfter(this.data.maxDate);
    }

    return disabled;
  }

  isDisabledRange(range): boolean {
    return !this.isAllowedRange(range);
  }

  setData(data: ConfigData = {}) {
    if (!data) {
      return;
    }

    const update = {};

    if (data.maxDate) {
      update['maxDate'] = data.maxDate.clone().endOf('day');
    }

    if (data.minDate) {
      update['minDate'] = data.minDate.clone().startOf('day').add(-1, 'seconds');
    }

    this.genWeekDays();
    this.data = { ...this.defaults, ...data, ...update };
  }

  validate(data: Moment): boolean {
    let hasError = false;

    this.activateErrorMsg();

    if (this.data.required && !data) {
      hasError = true;
      this.activateErrorMsg('required');
    }

    return hasError;
  }

  destroy(): void {

  }
}
