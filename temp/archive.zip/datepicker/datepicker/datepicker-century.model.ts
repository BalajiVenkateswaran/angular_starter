import { Moment } from 'moment';
import { RpDatepickerConfigModel as Config } from './datepicker-config.model';

export class RpDatepickerCenturyModel {
  ref: Moment;
  config: Config;
  decades: any [];
  selected: Moment;

  title = '';
  prevEnabled = false;
  nextEnabled = false;

  constructor() {
    this.decades = [];
  }

  destroy(): void {
    this.ref = undefined;
    this.title = undefined;
    this.config = undefined;
    this.decades = undefined;
    this.nextEnabled = undefined;
    this.prevEnabled = undefined;
  }

  genViewData(): void {
    const decade = this.getStart(),
      prev = decade.clone().add(-1, 'day'),
      end = decade.clone().endOf('year').add(90, 'years');

    this.decades = [];

    while (decade.isBefore(end)) {
      const state = {
        selected: this.isSelected(decade),
        disabled: this.isDisabled(decade)
      };

      this.decades.push({
        state: state,
        data: decade.clone(),
        text: decade.format('YYYY')
      });

      decade.add(10, 'years');
    }

    const first = this.decades[0].text,
      last = this.decades[this.decades.length - 1].text;

    this.title = `${first} - ${last}`;

    this.prevEnabled = this.config.isAllowed(prev);
    this.nextEnabled = this.config.isAllowed(decade);
  }

  getRef(): Moment {
    return this.ref;
  }

  getStart(): Moment {
    const start = this.ref.clone();
    let century = parseInt(this.ref.format('YYYY'), 10);
    century = 100 * Math.floor(century / 100);
    return start.year(century);
  }

  isAllowed(decade: Moment): boolean {
    return !this.isAllowed(decade);
  }

  isDisabled(decade: Moment): boolean {
    const start = decade.clone().startOf('year'),
      end = decade.clone().add(9, 'years').endOf('year');

    return this.config.isDisabledRange({
      end: end,
      start: start
    });
  }

  isSelected(decade: Moment): boolean {
    if (this.selected) {
      const year = parseInt(decade.format('YYYY'), 10),
        selYear = parseInt(this.selected.format('YYYY'), 10);
      return year <= selYear && selYear < year + 10;
    }

    return false;
  }

  nextCentury(): void {
    if (this.nextEnabled) {
      this.ref.add(100, 'years');
      this.genViewData();
    }
  }

  prevCentury(): void {
    if (this.prevEnabled) {
      this.ref.add(-100, 'years');
      this.genViewData();
    }
  }

  select(decade): void {
    this.selected = decade ? decade.data : undefined;
    this.setRef(this.selected);
  }

  selectDate(selectedDate: Moment): void {
    this.selected = selectedDate;
    this.setRef(selectedDate);
  }

  setConfig(config: Config): void {
    this.config = config;
  }

  setRef(ref?: Moment): void {
    if (ref) {
      this.ref = ref.clone();
      this.genViewData();
    }
  }
}
