import { Moment } from 'moment';
import { RpValidator } from '../../common/interfaces/validator.interface';
import { RpValidationMsg } from '../../common/interfaces/validation-msg.interface';

export interface RpDatepickerConfigData {
  dayIsDisabled?: Function;
  disabled?: boolean;
  displayFormat?: string;
  errorMsgs?: RpValidationMsg [];
  fieldID?: string;
  fieldName?: string;
  maxDate?: Moment;
  minDate?: Moment;
  parentId?: string;
  placeholder?: string;
  readonly?: boolean;
  required?: boolean;
  validators?: RpValidator[];
  wrapId?: string;
}
