import { Moment } from 'moment';
import * as moment from 'moment';
import { RpDatepickerConfigModel as Config } from './datepicker-config.model';

export class RpDatepickerMonthModel {
  title = '';
  days: any[];
  ref: Moment;
  config: Config;
  selected: Moment;
  nextEnabled = false;
  prevEnabled = false;

  constructor() {
    this.days = [];
    this.ref = moment().startOf('month');
  }

  destroy(): void {
    this.ref = undefined;
    this.days = undefined;
    this.title = undefined;
    this.config = undefined;
    this.selected = undefined;
    this.nextEnabled = undefined;
    this.prevEnabled = undefined;
  }

  genViewData(): void {
    const day = this.ref.clone().day(0),
      refMonth = this.ref.format('MM'),
      today = moment().startOf('day'),
      prev = day.clone().add(-1, 'days'),
      end = day.clone().add(5, 'weeks').endOf('week');

    this.days = [];
    this.title = this.ref.format('MMMM YYYY');

    while (day.isBefore(end)) {
      let selected = false;

      if (this.selected) {
        selected = this.selected.isSame(day);
      }

      const state = {
        selected: selected,
        today: today.isSame(day),
        current: refMonth === day.format('MM'),
        disabled: this.config.isDisabledItem(day.clone())
      };

      this.days.push({
        state: state,
        data: day.clone(),
        text: day.format('D')
      });

      day.add(1, 'day');
    }

    this.nextEnabled = this.config.allowNext(day);
    this.prevEnabled = this.config.allowPrev(prev);
  }

  getRef(): Moment {
    return this.ref;
  }

  nextMonth(): void {
    if (this.nextEnabled) {
      this.ref = this.ref.add(1, 'month');
      this.genViewData();
    }
  }

  prevMonth(): void {
    if (this.prevEnabled) {
      this.ref.add(-1, 'month');
      this.genViewData();
    }
  }

  select(selected): void {
    this.selected = selected ? selected.data : undefined;
    this.setRef(this.selected);
  }

  selectDate(selectedDate: Moment): void {
    this.selected = selectedDate;
    this.setRef(selectedDate);
  }

  setConfig(config: Config): void {
    this.config = config;
    this.genViewData();
  }

  setRef(ref?: Moment): void {
    if (ref) {
      this.ref = ref.clone().startOf('month');
    }
    this.genViewData();
  }
}
