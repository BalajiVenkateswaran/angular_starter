import { Moment } from 'moment';
import * as moment from 'moment';
import { RpDatepickerConfigModel as Config } from './datepicker-config.model';

export class RpDatepickerYearModel {
  title = '';
  ref: Moment;
  months: any[];
  config: Config;
  selected: Moment;
  nextEnabled = false;
  prevEnabled = false;

  constructor() {
    this.months = [];
  }

  destroy(): void {
    this.ref = undefined;
    this.title = undefined;
    this.months = undefined;
    this.config = undefined;
    this.selected = undefined;
    this.nextEnabled = undefined;
    this.prevEnabled = undefined;
  }

  genViewData(): void {
    const end = this.ref.clone().endOf('year'),
      month = this.ref.clone().startOf('year'),
      prev = month.clone().add(-1, 'day');

    this.months = [];
    this.title = this.ref.format('YYYY');

    while (month.isBefore(end)) {
      const state = {
        selected: this.isSelected(month),
        disabled: this.isDisabled(month)
      };

      this.months.push({
        state: state,
        data: month.clone(),
        text: month.format('MMM')
      });

      month.add(1, 'month');
    }

    this.prevEnabled = this.isAllowed(prev);
    this.nextEnabled = this.isAllowed(month);
  }

  getRef(): Moment {
    return this.ref;
  }

  isAllowed(month: Moment): boolean {
    return !this.isDisabled(month);
  }

  isDisabled(month: Moment): boolean {
    const end = month.clone().endOf('month'),
      start = month.clone().add(-1, 'second');

    return this.config.isDisabledRange({
      end: end,
      start: start
    });
  }

  isSelected(month: Moment): boolean {
    if (this.selected) {
      return this.selected.format('MM YYYY') === month.format('MM YYYY');
    }
    return false;
  }

  nextYear(): void {
    if (this.nextEnabled) {
      this.ref.add(1, 'year');
      this.genViewData();
    }
  }

  prevYear(): void {
    if (this.prevEnabled) {
      this.ref.add(-1, 'year');
      this.genViewData();
    }
  }

  select(selected): void {
    this.selected = selected ? selected.data : undefined;
    this.setRef(this.selected);
  }

  selectDate(selectedDate: Moment): void {
    this.selected = selectedDate;
    this.setRef(selectedDate);
  }

  setConfig(config: Config): void {
    this.config = config;
  }

  setRef(ref?: Moment): void {
    if (ref) {
      this.ref = ref.clone();
      this.genViewData();
    }
  }
}
