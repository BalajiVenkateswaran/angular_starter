import { Moment } from 'moment';
import { RpDatepickerYearModel as Year } from './datepicker-year.model';
import { RpDatepickerMonthModel as Month } from './datepicker-month.model';
import { RpDatepickerDecadeModel as Decade } from './datepicker-decade.model';
import { RpDatepickerCenturyModel as Century } from './datepicker-century.model';
import { RpEventStream as EventStream } from '../../common/models/event-stream.model';
import { Injectable } from '@angular/core';

@Injectable()

export class RpDatepickerPanelModel {
  year: Year;
  style: any;
  month: Month;
  decade: Decade;
  weekDays: any[];
  century: Century;
  selected: Moment;
  elem: HTMLElement;
  activeView: string;

  change: EventStream;
  updateValue: EventStream;

  viewState: {
    busy: boolean;
    year?: boolean;
    month?: boolean;
    decade?: boolean;
    hidden?: boolean;
    century?: boolean;
  };

  events: {
    change: EventStream;
    updateValue: EventStream;
  };

  constructor() {
    this.activeView = 'month';

    this.events = {
      change: new EventStream(),
      updateValue: new EventStream()
    };

    this.viewState = {
      busy: true,
      month: true,
      year: false,
      decade: false,
      century: false
    };

    this.year = new Year();
    this.month = new Month();
    this.decade = new Decade();
    this.century = new Century();
  }

  destroy(): void {
    this.year.destroy();
    this.month.destroy();
    this.decade.destroy();
    this.century.destroy();

    this.events.change.destroy();
    this.events.updateValue.destroy();

    this.year = undefined;
    this.month = undefined;
    this.events = undefined;
    this.decade = undefined;
    this.century = undefined;
    this.weekDays = undefined;
    this.viewState = undefined;
    this.activeView = undefined;
  }

  focusOn(viewName: string, item: any) {
    if (item.state.disabled) {
      return;
    }

    this.activeView = viewName;

    if (this[viewName] && this[viewName].setRef) {
      this[viewName].setRef(item.data);
    }

    for (const key in this.viewState) {
      if (this.viewState.hasOwnProperty(key)) {
        this.viewState[key] = key === viewName;
      }
    }
  }

  getHeight(): number {
    return this.elem.offsetHeight;
  }

  hidePanel(): void {
    this.viewState.hidden = true;
  }

  publish(eventName: string, data: any): void {
    if (this.events[eventName]) {
      this.events[eventName].publish(data);
    }
  }

  selectDate(selectedDate: Moment): void {
    this.updateSelected(selectedDate);
    this.publish('updateValue', selectedDate);
  }

  selectDay(day: any): void {
    if (!day.state.disabled && !day.state.selected) {
      this.year.select(day);
      this.month.select(day);
      this.decade.select(day);
      this.century.select(day);
      this.publish('change', day.data);
    }
  }

  setBusy(busy: boolean): void {
    this.viewState.busy = busy;
    this.viewState.hidden = !busy;
  }

  setData(data: any): void {
    const config = data.config;

    this.year.setConfig(config);
    this.month.setConfig(config);
    this.decade.setConfig(config);
    this.century.setConfig(config);

    this.selected = data.selected;
    this.weekDays = config.genWeekDays();

    if (this.selected) {
      this.selected.startOf('day');
      this.updateSelected(this.selected);
    }
  }

  setElem(elem: HTMLElement): void {
    this.elem = elem;
  }

  setReady(): void {
    this.setBusy(false);
  }

  setStyle(style: any): void {
    this.style = style;
  }

  showPanel(): void {
    this.viewState.hidden = false;
  }

  showView(viewName: string): void {
    const ref = this[this.activeView].getRef();

    for (const key in this.viewState) {
      if (this.viewState.hasOwnProperty(key)) {
        this.viewState[key] = key === viewName;
      }
    }

    this[viewName].setRef(ref);
    this.activeView = viewName;
  }

  subscribe(eventName: string, callback: Function): Function {
    if (this.events[eventName]) {
      return this.events[eventName].subscribe(callback);
    }
  }

  updateSelected(selected: Moment): void {
    this.year.selectDate(selected);
    this.month.selectDate(selected);
    this.decade.selectDate(selected);
    this.century.selectDate(selected);
  }
}
