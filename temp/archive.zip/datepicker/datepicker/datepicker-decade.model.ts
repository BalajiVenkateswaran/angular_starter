import { Moment } from 'moment';
import { RpDatepickerConfigModel as Config } from './datepicker-config.model';

export class RpDatepickerDecadeModel {
  title = '';
  ref: Moment;
  years: any[];
  config: Config;
  selected: Moment;
  prevEnabled = false;
  nextEnabled = false;

  constructor() {
    this.years = [];
  }

  destroy(): void {
    this.ref = undefined;
    this.title = undefined;
    this.years = undefined;
    this.config = undefined;
    this.selected = undefined;
    this.nextEnabled = undefined;
    this.prevEnabled = undefined;
  }

  genViewData(): void {
    const year = this.getViewStart(),
      prev = year.clone().add(-1, 'year'),
      end = year.clone().endOf('year').add(9, 'years');

    this.years = [];

    while (year.isBefore(end)) {
        const state = {
            selected: this.isSelected(year),
            disabled: this.isDisabled(year)
        };

        this.years.push({
            state: state,
            data: year.clone(),
            text: year.format('YYYY')
        });

        year.add(1, 'year');
    }

    const first = this.years[0].text,
      last = this.years[this.years.length - 1].text;

    this.title = `${first} - ${last}`;

    this.prevEnabled = this.isAllowed(prev);
    this.nextEnabled = this.isAllowed(year);
  }

  getRef(): Moment {
    return this.ref;
  }

  getViewStart(): Moment {
    const start = this.ref.clone();
    let year = parseInt(start.format('YYYY'), 10);
    year = 10 * Math.floor(year / 10);
    return start.year(year);
  }

  isAllowed(year: Moment): boolean {
    return this.isDisabled(year);
  }

  isSelected(year: Moment): boolean {
    if (this.selected) {
      return this.selected.format('YYYY') === year.format('YYYY');
    }
    return false;
  }

  isDisabled(year: Moment): boolean {
    const end = year.clone().endOf('year'),
      start = year.clone().startOf('year');

    return this.config.isDisabledRange({
      end: end,
      start: start
    });
  }

  nextDecade(): void {
    if (this.nextEnabled) {
      this.ref.add(10, 'years');
      this.genViewData();
    }
  }

  prevDecade(): void {
    if (this.prevEnabled) {
      this.ref.add(-10, 'years');
      this.genViewData();
    }
  }

  select(year): void {
    this.selected = year ? year.data : undefined;
    this.setRef(this.selected);
  }

  selectDate(selected): void {
    this.selected = selected;
    this.setRef(selected);
  }

  setConfig(config: Config): void {
    this.config = config;
  }

  setRef(ref?: Moment): void {
    if (ref) {
      this.ref = ref.clone();
      this.genViewData();
    }
  }
}
