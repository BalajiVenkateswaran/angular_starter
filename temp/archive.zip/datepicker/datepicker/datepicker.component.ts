import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
  OnDestroy,
  Renderer2,
  ElementRef,
  ViewEncapsulation
} from '@angular/core';

import { Moment } from 'moment';
import * as moment from 'moment';

import { RpDatepickerConfigData as ConfigData } from './datepicker-config-data.interface';
import { RpDatepickerConfigModel as Config } from './datepicker-config.model';
import { RpDatepickerPanelComponent as PickerPanel } from '../datepicker-panel/datepicker-panel.component';
import { RpDatepickerPanelModel as PanelModel } from './datepicker-panel.model';
import { RpDomService as DomSvc } from '../../common/services/dom.service';
import { RpPositioningService as PosnSvc } from '../../common/services/positioning.service';

@Component({
  providers: [PanelModel],
  selector: 'rp-datepicker',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.scss']
})

export class RpDatepickerComponent implements OnInit, OnDestroy {
  config: Config;
  selected: Moment;
  modelValue: string;
  hidePicker: Function;
  panelModel: PanelModel;
  unbindKeydown: Function;
  destroyPicker: Function;
  pickerChangeSub: Function;

  state: {
    error: boolean;
    focus: boolean;
    disabled: boolean;
    'has-error-msgs': boolean;
  };

  @Input('config') public set setConfig(data: ConfigData) {
    this.config.setData(data);
    this.state.disabled = this.config.isDisabled();
    this.state['has-error-msgs'] = this.config.hasErrorMsgs();
  }

  @Output() modelChange = new EventEmitter<Moment>();

  @Input('model') public set setModel(data: Moment) {
    this.validate(data);
    this.selected = data;
    this.modelValue = data ? this.config.getDisplayValue(data) : '';

    setTimeout(() => {
      this.panelModel.setData({
        config: this.config,
        selected: this.selected
      });

      this.panelModel.updateSelected(data);
    });
  }

  @ViewChild('wrap') wrap: ElementRef;

  constructor(private domSvc: DomSvc, private posnSvc: PosnSvc, private renderer: Renderer2) {
    const onPickerChange = this.onPickerChange.bind(this);

    this.state = {
      focus: false,
      error: false,
      disabled: false,
      'has-error-msgs': false
    };

    this.config = new Config();
    this.hidePicker = () => { };
    this.unbindKeydown = () => { };
    this.panelModel = new PanelModel();

    this.pickerChangeSub = this.panelModel.subscribe('change', onPickerChange);
  }

  bindBodyEvents() {
    const hidePanel = this.hidePanel.bind(this),
      onKeydown = this.onKeydown.bind(this);

    this.unbindKeydown = this.renderer.listen(document.body, 'keydown', onKeydown);

    setTimeout(() => {
      this.hidePicker = this.renderer.listen(document.body, 'click', hidePanel);
    }, 200);
  }

  hidePanel() {
    this.hidePicker();
    this.unbindKeydown();
    this.state.focus = false;
    this.panelModel.hidePanel();
  }

  installPicker() {
    const panelConfig = {
      inputs: {
        model: this.panelModel
      }
    };

    return this.domSvc.appendComponentTo(this.config.getParentId(), PickerPanel, panelConfig);
  }

  ngOnInit() {
    setTimeout(() => {
      this.destroyPicker = this.installPicker();
    });
  }

  ngOnDestroy() {
    this.destroyPicker();
  }

  onDisplayChange() {
    setTimeout(() => {
      const mv = this.config.getModel(this.modelValue);

      if (mv.isValid()) {
        this.selected = mv;
      } else {
        this.selected = undefined;
      }

      this.modelChange.emit(this.selected);
    });
  }

  onFocus() {
    this.showPanel();
    this.bindBodyEvents();
    this.state.focus = true;
  }

  onKeydown(event): void {
    const hideKeys = [9, 13, 27],
      updateKeys = [37, 38, 39, 40],
      unit = event.ctrlKey ? 'year' : 'week',
      mv = (this.selected || moment().startOf('day')).clone();

    if (hideKeys.indexOf(event.keyCode) !== -1) {
      this.hidePanel();
    } else if (updateKeys.indexOf(event.keyCode) !== -1) {
      if (event.keyCode === 38) {
        mv.add(-1, unit);
      } else if (event.keyCode === 40) {
        mv.add(1, unit);
      } else if (event.keyCode === 37) {
        mv.add(-1, 'day');
      } else if (event.keyCode === 39) {
        mv.add(1, 'day');
      }

      if (this.config.isAllowed(mv)) {
        this.validate(mv);
        this.selected = mv;
        this.modelChange.emit(this.selected);
        this.modelValue = this.config.getDisplayValue(mv);
      }
    }
  }

  onPickerChange(data) {
    this.validate(data);
    this.selected = data;
    this.modelChange.emit(this.selected);
  }

  showPanel(): void {
    this.panelModel.setBusy(true);

    this.posnSvc.setData({
      elem: this.wrap.nativeElement,
      parentId: this.config.getParentId()
    });

    setTimeout(() => {
      const panelHeight = this.panelModel.getHeight(),
      panelStyles = this.posnSvc.getStyles(panelHeight);

      this.panelModel.setBusy(false);
      this.panelModel.showPanel();
      this.panelModel.setStyle(panelStyles);
    });
  }

  validate(data: Moment): void {
    this.state['error'] = this.config.validate(data);
  }
}
