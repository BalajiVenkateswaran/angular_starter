import {
  Component,
  Input,
  ViewEncapsulation,
  OnInit,
  ElementRef,
  ViewChild
} from '@angular/core';

import { RpDatepickerPanelModel } from '../datepicker/datepicker-panel.model';

@Component({
  selector: 'rp-datepicker-panel',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './datepicker-panel.component.html',
  styleUrls: ['./datepicker-panel.component.scss']
})

export class RpDatepickerPanelComponent implements OnInit {
  @Input() model: RpDatepickerPanelModel;

  @ViewChild('wrap') wrap: ElementRef;

  constructor() { }

  ngOnInit() {
    this.model.setReady();
    this.model.setElem(this.wrap.nativeElement);
  }
}
