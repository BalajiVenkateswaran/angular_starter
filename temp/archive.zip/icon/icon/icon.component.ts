import { Component, ElementRef, Input, OnDestroy, ViewEncapsulation } from '@angular/core';
import { RpIconService as IconService } from './icon.service';
import { RpIconListService as IconListService } from './icon-list.service';

@Component({
  selector: 'rp-icon',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './icon.component.html',
  styleUrls: ['./icon.component.scss']
})

export class RpIconComponent implements OnDestroy {
  prevName: string;

  @Input('name') public set setName(name: string) {
    const newName = this.prevName !== name,
      validName = this.listSvc.contains(name);

    if (newName && validName) {
      this.prevName = name;
      this.iconSvc.getIcon(name, this.appendIcon.bind(this));
    }
  }

  constructor(
    private elem: ElementRef,
    private iconSvc: IconService,
    private listSvc: IconListService) { }

  appendIcon(data: string) {
    this.elem.nativeElement.innerHTML = data;
  }

  ngOnDestroy() {
    const elem = this.elem.nativeElement;

    while (elem.firstChild) {
      elem.removeChild(elem.firstChild);
    }
  }
}
