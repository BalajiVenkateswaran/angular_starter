import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { RpIconCacheService as Cache } from './icon-cache.service';

@Injectable()

export class RpIconService {
  callbacks: any;

  constructor(
    private http: Http,
    private cache: Cache) {
    this.callbacks = {};
  }

  getIcon(name: string, callback: Function): void {
    if (this.cache.hasIcon(name)) {
      callback(this.cache.getIcon(name));
      return;
    }

    this.queReq(name, callback);
  }

  queReq(name: string, callback: Function): void {
    this.callbacks[name] = this.callbacks[name] || [];

    this.callbacks[name].push({
      callback: callback
    });

    if (this.callbacks[name].length === 1) {
      this.reqIcon(name);
    }
  }

  reqIcon(name: string) {
    const url = 'https://cdn.realpage.com/images/icons/' + name + '.svg';

    this.http.get(url).subscribe((data: Response) => {
      this.execCallback(name, data.text());
    });
  }

  execCallback(name: string, data: any): void {
    this.cache.store(name, data);

    this.callbacks[name].forEach((item) => {
      item.callback(data);
    });

    delete this.callbacks[name];
  }
}
