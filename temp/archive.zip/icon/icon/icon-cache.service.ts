import { Injectable } from '@angular/core';

@Injectable()

export class RpIconCacheService {
  iconData: any;

  constructor() {
    this.iconData = {};
  }

  getIcon(name: string): any {
    return this.iconData[name];
  }

  hasIcon(name: string): boolean {
    return !!this.iconData[name];
  }

  store(name: string, data: any): void {
    this.iconData[name] = data;
  }
}
