import { NgModule } from '@angular/core';
import { RpIconComponent } from './icon/icon.component';
import { RpIconCacheService } from './icon/icon-cache.service';
import { RpIconService } from './icon/icon.service';
import { HttpModule } from '@angular/http';
import { RpIconListService } from './icon/icon-list.service';

@NgModule({
  declarations: [
    RpIconComponent
  ],

  imports: [
    HttpModule
  ],

  exports: [
    RpIconComponent
  ],

  providers: [
    RpIconService,
    RpIconListService,
    RpIconCacheService
  ]
})

export class RpIconModule { }
