import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpWindowProvider } from './services/window.provider';
import { RpTrimSpaceDirective } from './directives/trim-space.directive';
import { RpDomService } from './services/dom.service';
import { RpSessionStorageService } from './services/session-storage.service';
import { RpPositioningService } from './services/positioning.service';

@NgModule({
  declarations: [
    RpTrimSpaceDirective
  ],

  imports: [
    CommonModule
  ],

  exports: [
    RpTrimSpaceDirective
  ],

  providers: [
    RpDomService,
    RpWindowProvider,
    RpPositioningService,
    RpSessionStorageService
  ]
})

export class RpCommonModule { }
