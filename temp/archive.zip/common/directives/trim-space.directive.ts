import { Directive, Input, OnInit, ElementRef } from '@angular/core';

@Directive({
  selector: '[rpTrimSpace]'
})

export class RpTrimSpaceDirective implements OnInit {
  @Input('rpTrimSpace') spaceCount: number;

  constructor(private elem: ElementRef) { }

  ngOnInit() {
    const html = this.elem.nativeElement.innerHTML,
      exp = new RegExp('(\n|\r|\n\r|\r\n) {' + this.spaceCount + '}', 'g');
    this.elem.nativeElement.innerHTML = html.replace(exp, '$1').trim();
  }
}
