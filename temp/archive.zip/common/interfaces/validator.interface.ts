export interface RpValidator {
  name: string;
  method: Function;
}
