export interface RpValidationMsg {
  name: string;
  text: string;
  active?: boolean;
}
