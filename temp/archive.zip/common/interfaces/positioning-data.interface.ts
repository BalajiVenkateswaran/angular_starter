export interface RpPositioningData {
  parentId?: string;
  elem: HTMLElement;
}
