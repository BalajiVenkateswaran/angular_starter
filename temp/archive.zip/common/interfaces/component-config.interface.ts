export interface RpComponentConfig {
  inputs: object;
  outputs?: object;
}
