export class RpEventStreamItem {
  id: string;
  callback: Function;

  constructor(id: string, callback: Function) {
    this.id = id;
    this.callback = callback;
  }

  getID() {
    return this.id;
  }

  execCallback(data: any) {
    this.callback(data);
  }

  hasID(id: string) {
    return this.id === id;
  }

  is(item: RpEventStreamItem) {
    return item.getID() === this.id;
  }
}
