import { RpEventStreamItem } from './event-stream-item.model';

export class RpEventStream {
  count: number;
  list: RpEventStreamItem [];

  constructor() {
    this.list = [];
    this.count = 1;
  }

  destroy(): void {
    this.list = undefined;
    this.count = undefined;
  }

  publish(data) {
    this.list.forEach((item) => {
      item.execCallback(data);
    });
    return this;
  }

  reset() {
    this.list = [];
    return this;
  }

  subscribe(callback: Function) {
    const id = `evt${this.count++}`;
    this.list.push(new RpEventStreamItem(id, callback));
    return () => {
      this.unsubscribe(id);
    };
  }

  unsubscribe(id: string) {
    this.list = this.list.filter((item) => {
      return !item.hasID(id);
    });
  }
}
