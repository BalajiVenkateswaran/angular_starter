import { Injectable, Inject } from '@angular/core';
import { environment as env } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})

export class RpLoggingService {
  constructor(@Inject('Window') private win) {}

  msg(...data) {
    if (!env.production && this.win.console && this.win.console.log) {
      this.win.console.log.apply(console, arguments);
    }
  }

  warn(...data) {
    if (!env.production && this.win.console && this.win.console.warn) {
      this.win.console.warn.apply(console, arguments);
    }
  }
}
