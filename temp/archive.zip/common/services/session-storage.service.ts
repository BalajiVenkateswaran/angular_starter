import { Injectable, Inject } from '@angular/core';

@Injectable({ providedIn: 'root' })

export class RpSessionStorageService {
  storage: any;

  constructor(@Inject('Window') private win) {
    this.storage = this.win.sessionStorage;
  }

  set(name: string, value): void {
    this.storage[name] = this.win.JSON.stringify(value);
  }

  get(name: string): any {
    return this.win.JSON.parse(this.storage[name]);
  }

  del(name: string): void {
    delete this.storage[name];
  }

  has(name: string): boolean {
    return this.storage[name] !== undefined;
  }
}
