import { Injectable } from '@angular/core';
import { RpNavModel } from '../../nav/nav/nav.model';

@Injectable({ providedIn: 'root' })

export class AppLayoutService {
  navHidden = false;
  headerHidden = false;
  appHeaderHidden = false;

  constructor(private nav: RpNavModel) {}

  getState() {
    const navState = this.nav.getState();

    const layoutState = {
      'rp-nav-hidden': this.navHidden,
      'rp-header-hidden': this.headerHidden,
      'rp-app-header-hidden': this.appHeaderHidden
    };

    return { ...navState, ...layoutState };
  }

  hideAppHeader(): void {
    this.appHeaderHidden = true;
  }

  hideHeader(): void {
    this.headerHidden = true;
  }

  hideNav(): void {
    this.navHidden = true;
  }

  showAppHeader(): void {
    this.appHeaderHidden = false;
  }

  showHeader(): void {
    this.headerHidden = false;
  }

  showNav(): void {
    this.navHidden = false;
  }
}
