import {
  ApplicationRef,
  ComponentFactoryResolver,
  ComponentRef,
  EmbeddedViewRef,
  Injectable,
  Injector,
  ViewRef
} from '@angular/core';

import { RpComponentConfig as CompConfig } from '../interfaces/component-config.interface';

@Injectable()

export class RpDomService {
  constructor(
    private inj: Injector,
    private appRef: ApplicationRef,
    private resolver: ComponentFactoryResolver
  ) { }

  public appendComponentTo(parentId: string, comp: any, compConfig?: CompConfig): Function {
    // Create a component reference from the component
    const compRef = this.genCompRef(comp);

    // Attach the config to the child (inputs and outputs)
    if (compConfig) {
      this.attachConfig(compRef, compConfig);
      compRef.changeDetectorRef.detectChanges();
    }

    // Attach component to the appRef so that it's inside the ng component tree
    this.attachView(compRef.hostView);

    // Get DOM element from component
    const compElem = this.genCompElem(compRef);

    // Append DOM element to the body
    this.appendElem(parentId, compElem);

    return () => {
      this.detachView(compRef.hostView);
      compRef.destroy();
    };
  }

  attachView(viewRef: ViewRef): void {
    this.appRef.attachView(viewRef);
  }

  detachView(view: ViewRef): void {
    this.appRef.detachView(view);
  }

  genCompRef(component: any): ComponentRef<any> {
    return this.resolver
      .resolveComponentFactory(component)
      .create(this.inj);
  }

  genCompElem(compRef: ComponentRef<any>): HTMLElement {
    return (compRef.hostView as EmbeddedViewRef<any>)
      .rootNodes[0] as HTMLElement;
  }

  appendElem(parentId: string, elem: HTMLElement): void {
    document.getElementById(parentId).appendChild(elem);
  }

  attachConfig(compRef, compConfig: CompConfig) {
    const inputs = compConfig.inputs;
    const outputs = compConfig.outputs;

    for (const key in inputs) {
      if (inputs.hasOwnProperty(key)) {
        compRef.instance[key] = inputs[key];
      }
    }

    for (const key in outputs) {
      if (inputs.hasOwnProperty(key)) {
        compRef.instance[key] = outputs[key];
      }
    }
  }
}
