import { Injectable, Inject } from '@angular/core';

import { RpPositioningData as PositioningData } from '../interfaces/positioning-data.interface';

@Injectable()

export class RpPositioningService {
  elem: HTMLElement;
  parent: HTMLElement;
  data: PositioningData;

  constructor(@Inject('Window') private win) { }

  getElemData(): any {
    return {
      height: this.elem.offsetHeight,
      offsetTop: this.elem.offsetTop,
      offsetLeft: this.elem.offsetLeft
    };
  }

  getParentData(): any {
    return {
      height: this.parent.offsetHeight,
      offsetTop: this.parent.offsetTop,
      offsetLeft: this.parent.offsetLeft,
      scrollTop: this.parent.scrollTop,
      scrollLeft: this.parent.scrollLeft
    };
  }

  getParentPosn(menuHeight: number): any {
    const space = this.getSpace(),
      elem = this.getElemData(),
      par = this.getParentData(),
      left = elem.offsetLeft - par.offsetLeft - par.scrollLeft;

    let top = elem.offsetTop - par.offsetTop - par.scrollTop;

    if (space.bottom < menuHeight && space.bottom < space.top) {
      top -= menuHeight;
    } else {
      top += elem.height;
    }

    return {
      'top.px': top,
      'left.px': left
    };
  }

  getPosn(menuHeight: number): any {
    const left = 0,
      space = this.getSpace(),
      elem = this.getElemData();

    let top = elem.height;

    if (space.bottom < menuHeight && space.bottom < space.top) {
      top -= menuHeight;
    }

    return {
      'top.px': top,
      'left.px': left
    };
  }

  getRootPosn(menuHeight: number): any {
    const elem = this.getElemData(),
      space = this.getSpace(),
      left = elem.offsetLeft;

    let top = elem.offsetTop;

    if (space.bottom < menuHeight && space.bottom < space.top) {
      top -= menuHeight;
    } else {
      top += elem.height;
    }

    return {
      'top.px': top,
      'left.px': left
    };
  }

  getSpace(): any {
    let top = 0,
      bottom = 0;

    const win = this.getWinData(),
      elem = this.getElemData();

    if (this.data.parentId !== 'rp-app-root') {
      const par = this.getParentData(),
        topLim1 = elem.offsetTop - win.scrollTop - par.scrollTop,
        topLim2 = elem.offsetTop - par.offsetTop - par.scrollTop,
        botLim1 = win.scrollTop + win.height - elem.offsetTop - elem.height,
        botLim2 = par.offsetTop + par.height - elem.offsetTop - elem.height;

      top = topLim1 > topLim2 ? topLim2 : topLim1;
      bottom = botLim1 > botLim2 ? botLim2 : botLim1;
    } else {
      top = elem.offsetTop - win.scrollTop;
      bottom = win.height - top - elem.height;
    }

    return {
      top: top,
      bottom: bottom
    };
  }

  getStyles(menuHeight: number): any {
    let posn: any;

    if (!this.data.parentId) {
      posn = this.getPosn(menuHeight);
    } else if (this.data.parentId === 'rp-app-root') {
      posn = this.getRootPosn(menuHeight);
    } else {
      posn = this.getParentPosn(menuHeight);
    }

    return posn;
  }

  getWinData(): any {
    return {
      height: this.win.innerHeight,
      scrollTop: this.win.scrollY
    };
  }

  destroy() {
    this.data = {
      elem: undefined
    };

    this.elem = undefined;
    this.parent = undefined;
  }

  setData(data: PositioningData): void {
    this.data = { ...this.data, ...data };

    this.elem = this.data.elem;

    if (this.data.parentId) {
      this.parent = document.getElementById(this.data.parentId);
    }
  }
}
