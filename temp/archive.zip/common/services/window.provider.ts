const RpWindowFactory = () => {
  return window;
};

export let RpWindowProvider = {
  provide: 'Window',
  useFactory: RpWindowFactory
};
