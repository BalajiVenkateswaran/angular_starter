import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })

export class PubSub {
  private static instance: PubSub;

  count = 1;
  events: object = {};

  constructor() {
    if (!PubSub.instance) {
      PubSub.instance = this;
    }

    return PubSub.instance;
  }

  publish(eventName: string, eventData: any = null): void {
    if (this.events[eventName]) {
      this.events[eventName].forEach((item) => {
        item.callback(eventData);
      });
    }
  }

  reset(eventName: string): void {
    if (eventName !== undefined && this.events[eventName]) {
      delete this.events[eventName];
    }
  }

  subscribe(eventName: string, callback: Function): Function {
    const id = `event${this.count++}`;

    if (this.events[eventName] === undefined) {
      this.events[eventName] = [];
    }

    this.events[eventName].push({
      id: id,
      callback: callback
    });

    return () => {
      this.unsubscribe(eventName, id);
    };
  }

  unsubscribe(eventName: string, id: string): void {
    if (this.events[eventName]) {
      this.events[eventName] = this.events[eventName].filter((item) => {
        return item.id !== id;
      });
    }
  }
}
