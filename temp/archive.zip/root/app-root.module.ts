import { NgModule } from '@angular/core';
import { RpAppRootDirective } from './root/app-root.directive';

@NgModule({
  declarations: [
    RpAppRootDirective
  ],

  imports: [

  ],

  exports: [
    RpAppRootDirective
  ],

  providers: [

  ]
})

export class RpAppRootModule { }
