import { Directive } from '@angular/core';
import { RpPageTitleService } from '../../page-title/page-title/page-title.service';

@Directive({
  selector: '[id="rp-app-root"]'
})

export class RpAppRootDirective {
  constructor(private pageTitle: RpPageTitleService) { }
}
