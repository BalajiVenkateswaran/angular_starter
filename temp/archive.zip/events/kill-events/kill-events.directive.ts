import {
  Directive,
  Input,
  Renderer2,
  ElementRef,
  OnInit,
  OnDestroy
} from '@angular/core';

@Directive({
  selector: '[rpKillEvents]'
})

export class RpKillEventsDirective implements OnInit, OnDestroy {
  list: Function[];
  @Input() rpKillEvents: string[];
  @Input() rpKillEventsDisabled: boolean;

  constructor(private renderer: Renderer2, private elem: ElementRef) {
    this.list = [];
  }

  callback($event) {
    if (this.rpKillEventsDisabled !== true) {
      $event.preventDefault();
      $event.stopPropagation();
    }
  }

  ngOnInit() {
    if (this.rpKillEvents) {
      const elem = this.elem.nativeElement;

      this.rpKillEvents.forEach((event) => {
        const cb = this.renderer.listen(elem, event, this.callback.bind(this));
        this.list.push(cb);
      });
    }
  }

  ngOnDestroy() {
    this.list.forEach((cb) => {
      cb();
    });

    this.list = [];
  }
}
