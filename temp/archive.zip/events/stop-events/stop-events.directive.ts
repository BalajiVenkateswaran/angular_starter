import {
  Directive,
  Input,
  Renderer2,
  ElementRef,
  OnInit,
  OnDestroy
} from '@angular/core';

@Directive({
  selector: '[rpStopEvents]'
})

export class RpStopEventsDirective implements OnInit, OnDestroy {
  list: Function[];
  @Input() rpStopEvents: string[];
  @Input() rpStopEventsDisabled: boolean;

  constructor(private renderer: Renderer2, private elem: ElementRef) {
    this.list = [];
  }

  callback($event) {
    if (this.rpStopEventsDisabled !== true) {
      $event.stopPropagation();
    }
  }

  ngOnInit() {
    if (this.rpStopEvents) {
      const elem = this.elem.nativeElement;

      this.rpStopEvents.forEach((event) => {
        const cb = this.renderer.listen(elem, event, this.callback.bind(this));
        this.list.push(cb);
      });
    }
  }

  ngOnDestroy() {
    this.list.forEach((cb) => {
      cb();
    });

    this.list = [];
  }
}
