import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RpKillEventsDirective } from './kill-events/kill-events.directive';
import { RpStopEventsDirective } from './stop-events/stop-events.directive';

@NgModule({
  declarations: [
    RpKillEventsDirective,
    RpStopEventsDirective
  ],

  imports: [
    CommonModule
  ],

  exports: [
    RpKillEventsDirective,
    RpStopEventsDirective
  ]
})

export class RpEventsModule { }
